# g6-afrikaans-home-language-exam-t4

**AI moderator verdict:** NEEDS_WORK  |  **score:** 3/5  |  **version:** original

## AI recommendation

This paper requires targeted rework before publication. The structural compliance is solid (clear cover, logical section progression, good stimulus quality), and the memo answers are factually sound. However, four BLOCKING cognitive-level labelling errors (Questions 4.3, 4.4, 4.5, and a weaker case for 4.5) undermine the integrity of the paper—teachers will spot these mismatches immediately and lose confidence. A more significant issue is the subject-language mismatch: the paper is labelled 'Afrikaans Home Language' but is entirely in English, which violates subject-specific curriculum expectations. Finally, the curriculum-coverage claim (Terms 3–4 literary review) does not match the actual content (non-fiction only). These are fixable: relabel cognitive levels (30 min), clarify subject/language (decide whether to make it fully Afrikaans or relabel to English), and either add a literary text or correct the meta-data. Once these are addressed, the paper will be publication-ready.

## Dimension scores (1-5)

| Dimension | Score | Notes |
|---|---|---|
| memoAccuracy | 4/5 | Memo answers are factually correct and well-supported. Marking guidance is clear and actionable. Minor: Question 2.1 rubric allows 4 marks for content but memo awards only 3; this needs clarification in implementation. |
| cognitiveLevelIntegrity | 2/5 | Multiple mismatches between labelled and actual cognitive demand. Questions 4.3 and 4.4 are labelled Literal but require synonym/antonym recognition (Reorganisation). Question 4.5 is labelled Inferential but is a definition-plus-explanation task (Reorganisation). Questions 1.2, 3.3, 3.5 all show minor labelling inconsistencies. |
| topicAlignment | 2/5 | All questions claim the same topic: 'Eindeksamen (50 punte): literêre/nie-literêre teks (20), visuele teks (10), opsomming (10), taalstrukture (10)' — a summary of exam structure, not a topic. This is not topic alignment; it is a meta-label. Section D questions should be labelled 'Taalstrukture: hersiening — alle taalstrukture' consistently, which some are. Needs clearer topic-to-question mapping. |
| markFairness | 3/5 | Marks are broadly reasonable but some allocations feel uneven. Q1.2 (3 marks for one quote) and Q1.4 (2 marks for three items, ~0.67 per item) create inconsistency. Q1.5 (6 marks) is much heavier than Q1.6 (3 marks) for comparable inferential tasks. Q2.1 memo says 3 marks but rubric structure suggests 4+1=5-mark design. |
| mcqQuality | 5/5 | No MCQ questions in this paper; not applicable. |
| questionClarity | 4/5 | Most questions are clear and unambiguous. Minor: Question 1.8 is double-barrelled (asks learner to both agree/disagree AND justify with text+own knowledge), which complicates the demand. Question 4.5 combines two tasks (identify relationship AND explain writer's choice) without clear separation. |
| stimulusQuality | 4/5 | Passage is well-written, age-appropriate, and coherent (310 words fits Gr6). Visual text is described in sufficient detail for questions to be answerable. Minor: Visual description is entirely verbal; no actual image provided. This is acceptable for an exam paper if the description is precise, which it is. |
| capsCompliance | 4/5 | Cover page is complete with instructions and learner fields. Four sections (A–D) are ordered from lower to higher cog level (Literal/Reorganisation → Inferential/Evaluation). Exam label, subject, grade, term, marks, duration all present. Minor: Instructions are in English; subject is Afrikaans Home Language. Normally cover should match exam language, but this may be intentional for Gr6 EMC. |
| languageRegister | 4/5 | Grammar and spelling are generally correct. Register is appropriate for Grade 6. Vocabulary is accessible. Minor: 'Afrikaans Home Language' paper presented entirely in English; no Afrikaans text or questions appear. This is a significant deviation from subject expectation, though may reflect the 'language: English' meta-flag. Warrants advisory flag. |
| biasSensitivity | 4/5 | No gender, racial, or socioeconomic stereotyping detected. Passage and questions acknowledge SA context (rural communities, water access inequity) respectfully. Names are not foregrounded as gendered. Minor: hypothetical child in Q1.7 is gender-neutral; example is inclusive. |
| culturalContext | 5/5 | Excellent SA grounding: passage references rural SA water scarcity, cholera/typhoid epidemiology, Department of Water and Sanitation, and local climate impacts. Poster includes Afrikaans-language cues ('Lees en Kyk') reinforcing local context. Culturally responsive. |
| curriculumCoverage | 3/5 | Paper claims to cover Terms 3–4 topics. Topics listed include literature review (roman, kortverhaal, volksverhaal, drama, gedigte) but exam contains no literary text — only non-fiction passage and poster. Language structures (saamgestelde sinne, betreklike bysinne) are partly addressed (Q4.1 covers relative clauses) but compound sentences are not tested directly. Coverage is narrow and does not reflect the breadth of Term 3–4 topics claimed. |

## BLOCKING issues (3)

- **Q4.3 — cognitiveLevelIntegrity**
  - Issue: Question 4.3 is labelled 'Literal' but asks learners to find synonyms from the passage. Synonym recognition is a Reorganisation task (learners must understand meaning and select equivalent terms), not Literal (which is simple recall or extraction of directly stated information). Memo guidance ('Accept any valid synonym that appears in the passage') confirms the Reorganisation demand.
  - Suggested fix: Relabel Q4.3 as 'Reorganisation'.

- **Q4.4 — cognitiveLevelIntegrity**
  - Issue: Question 4.4 is labelled 'Literal' but asks learners to generate antonyms (opposite in meaning). Antonym generation requires understanding semantic relationships and producing new vocabulary not in the text — this is Reorganisation, not Literal recall.
  - Suggested fix: Relabel Q4.4 as 'Reorganisation'.

- **Q4.5 — cognitiveLevelIntegrity**
  - Issue: Question 4.5 is labelled 'Inferential' but the task is to explain what 'maar' (but) means as a connector and why the writer uses it. This is primarily a Reorganisation task (learners must identify the contrast/relationship and explain the connective's function) with a brief inferential element (why in context). The memo guidance ('For identifying the contrast/contradiction AND explaining why this is meaningful') confirms the emphasis is on explaining a linguistic relationship, not drawing inferences beyond the text.
  - Suggested fix: Relabel Q4.5 as 'Reorganisation' or create a clearer split: lower marks for identifying contrast (Reorganisation) and higher marks for inferring writer's intent (Inferential).

## Advisory issues (5)

- **Qcover — languageRegister**: The paper is marked 'Afrikaans Home Language' as subject, yet all instructions, questions, stimuli, and memo are in English. No Afrikaans questions or texts appear. This contradicts the subject label and curriculum expectation for Afrikaans Home Language assessment, which should require learners to read, comprehend, and respond in Afrikaans (at least in part).
- **Q1 — topicAlignment**: All questions in Section A (and throughout the paper) are labelled with the topic 'Eindeksamen (50 punte): literêre/nie-literêre teks (20), visuele teks (10), opsomming (10), taalstrukture (10)'. This is not a topic—it is a summary of exam structure/marks distribution. True topics should specify the skill or content being tested (e.g., 'Non-fiction passage comprehension', 'Relative clause formation', 'Visual text analysis'). This labelling makes it impossible to verify topic-to-question alignment.
- **Q2.1 — markFairness**: Question 2.1 is awarded 3 marks, but the memo rubric suggests 4 marks for content (1 per point) plus 1 mark for own words = 5 marks total. The memo then states '[Marks awarded: 3 marks]' and lists content, language, own words as if they should total 3. This creates confusion for teachers implementing the mark allocation. The wording 'Award 0 for paraphrase' in Q1.2 memo contradicts Q2.1 memo which expects own words from a passage summary—own words IS paraphrase of the source.
- **Q1.2 — markFairness**: Question 1.2 asks for ONE sentence quotation and awards 3 marks. This is disproportionate: most quotation tasks at Grade 6 are 1–2 marks. Q1.1 asks for a factual recall and is 1 mark; Q1.2 asks for quotation and is 3 marks. The memo guidance ('For an accurate, relevant quote… For a partially relevant quote… Award 0 for paraphrase') suggests a 3-tier scale but only 3 marks total, making partial credit awkward.
- **QcurriculumCoverage — curriculumCoverage**: The meta-data claims this exam covers Terms 3 and 4 and lists topics including 'hersiening van alle genres (roman, kortverhaal, volksverhaal, drama, gedigte)' [review of all genres: novel, short story, folk tale, drama, poems]. However, the exam contains no literary texts—only a non-fiction passage (water crisis), a visual poster, and language exercises. No novel, short story, folk tale, drama, or poetry is tested. This is a significant mismatch between declared scope and actual content.

---

### What we want from your review

1. Open the DOCX file. Read it as if you received it from a colleague.
2. Would you publish it for your class as-is? With minor edits? Not at all?
3. Look at the AI moderator's verdict above. Does it match your judgement?
   - If the AI said PASS but you would NOT publish: what did it miss?
   - If the AI flagged BLOCKING issues but you would publish anyway: which flags are pedantic?
4. Are there ANY pedagogical issues the AI didn't catch?
