# g6-afrikaans-first-additional-language-exam-t2

**AI moderator verdict:** NEEDS_WORK  |  **score:** 3/5  |  **version:** original

## AI recommendation

This Grade 6 Afrikaans FAL paper is well-designed in content and context, with strong SA relevance, age-appropriate stimuli, and balanced coverage of reading, language, and visual literacy. However, it contains one critical blocker (Q2 mark allocation vs. instruction mismatch) and three advisory issues that undermine teacher clarity and mark reliability. The memo answer for Q1.3 contradicts the marked allocation (2 marks vs. 'up to 3 marks'), and Q1.4's 6-mark allocation is disproportionately high compared to other questions. Cognitive level labelling in Q1.3 understates the demand (Reorganisation vs. Inferential). These issues are fixable with targeted edits: align Q2 marks to either 5 or 3; rewrite Q1.3 memo guidance for unambiguous application; rebalance Q1.4 marks; and relabel Q1.3 cognitive level. Recommend NEEDS_WORK: targeted regen of the identified sections will bring the paper to publication-ready status.

## Dimension scores (1-5)

| Dimension | Score | Notes |
|---|---|---|
| memoAccuracy | 4/5 | Most memo answers are factually sound and traceable to the stimulus. However, memo guidance for Q1.3 contains an inconsistency: it says 'Per valid effect (up to 3 marks)' when the question allocates only 2 marks total, creating confusion for teachers about how to apply the rubric. |
| cognitiveLevelIntegrity | 3/5 | Significant misalignment detected in Section A. Q1.3 is labelled 'Reorganisation' but requires learners to infer and generalise consequences ('what happens during a drought'), which is Inferential work. Q1.4–1.6 and 7.3 are labelled 'Inferential' but are closer to mixed Reorganisation + Inferential, requiring explicit passage references for literal support before inference. |
| topicAlignment | 4/5 | Questions align with stated topics across sections. Language structure questions (Q3–6) appropriately test the listed grammar domains, and visual text questions test the prescribed reading and viewing skills. |
| markFairness | 3/5 | Mark allocation is uneven. Section A: Q1.1 (1 mark for literal recall) and Q1.7 (3 marks for opinion + evidence) are proportionate. However, Q1.4 awards 6 marks for a single inferential question—the highest mark on the exam for any single question—while Q1.2 awards only 2 marks for a direct quote. Section B allocates only 3 marks for a summary requiring 5 key points, creating a ceiling-effect issue. |
| mcqQuality | 5/5 | No MCQ items in this paper; dimension is not applicable but marked neutral. |
| questionClarity | 4/5 | Most stems are clear and unambiguous. Q1.7 ('Do you agree...') and Q7.4 ('How effective...') are slightly complex with multiple demands but are manageable. Q2 instruction to 'Write FIVE key points' but mark for 3 is a clarity hazard (see markFairness). |
| stimulusQuality | 4/5 | Both stimuli are fit for purpose. The passage is coherent, age-appropriate (230 words), and SA-contextualised (water scarcity, Northern Cape, rainfall stats). The visual text description is detailed enough to answer questions. No missing references. |
| capsCompliance | 4/5 | Cover page is complete with all required learner info fields and examiner field. Instructions are clear. Sections progress logically from Reading (A) to Summary (B) to Language/Visual (C), broadly following cognitive progression. However, the summary (B) allocated only 3 marks contradicts the instruction asking for 5 points. |
| languageRegister | 4/5 | English instructions and question stems are grammatically correct and age-appropriate for Grade 6. Afrikaans language-structure sentences are sound and realistic. No spelling or register errors detected. Note: memo answers are given in English rather than Afrikaans, which is acceptable as a teacher's guide. |
| biasSensitivity | 5/5 | No gender, racial, or socioeconomic stereotyping detected. The stimuli centre on a universal issue (water conservation) with SA-diverse contexts (rural/urban, farming communities). Names and references are inclusive and non-stereotypical. |
| culturalContext | 5/5 | Excellent SA contextualisation: Northern Cape droughts, 450 mm rainfall statistic, farming communities, rural water collection, and a fictional 'Water Wise South Africa' campaign logo. All contextual choices strengthen relevance for Grade 6 learners in SA. |
| curriculumCoverage | 4/5 | Good spread across term 2 topics: Reading (informational text), Summary, Tense Change, Indirect Speech, Passive Voice, Figurative Language, and Visual Text analysis. Notably absent: Nouns (soortnaamwoorde, abstrakte naamwoorde), Pronouns, and Punctuation mentioned in the topic scope, though Section C header claims to address them. |

## BLOCKING issues (2)

- **Q2 — markFairness**
  - Issue: Section B instruction: 'Write a summary of the passage... Your summary must include FIVE key points... You will be awarded 1 mark per valid point (up to 5 marks).' However, the question allocated only 3 marks in the header ('"marks": 3'). A teacher awarding marks will be confused: should they award 1 mark per key point (ceiling 5) or stop at 3? This is a fundamental inconsistency.
  - Suggested fix: Clarify: either increase the allocated marks to 5 ('marks: 5') to match the instruction, or reduce the instruction to 'Write THREE key points' and keep marks at 3. The meta data must align with the stem instruction.

- **Q1.3 — markingGuidance**
  - Issue: Memo guidance states: '[Marks awarded: 2 marks] Per valid effect (up to 3 marks): rivers dry up; crops fail; animals suffer; farming communities are hard hit. Deduct marks if learner copies directly...' This contains a contradiction: it says '2 marks' then 'up to 3 marks.' The phrase 'Per valid effect (up to 3 marks)' suggests a 3-mark ceiling, but the question is allocated only 2 marks. Teachers cannot apply this guidance unambiguously.
  - Suggested fix: Rewrite the memo guidance: 'Award up to 2 marks for explaining THREE effects of a drought. Award 1 mark for two effects paraphrased, or 2 marks for three effects with clear own-word explanation. Deduct marks if directly copied.' Clarify that the maximum is 2, not 3.

## Advisory issues (3)

- **Q1.3 — cognitiveLevelIntegrity**: Q1.3 is labelled 'Reorganisation' ('In your own words, explain what happens during a drought. Mention THREE effects...'), but the stem demands learners synthesise and generalise from passage details to a broader explanation—this is Inferential-level work, not Reorganisation (which is simply reordering/listing from text). The cognitive level is understated.
- **Q1.4 — markFairness**: Q1.4 is allocated 6 marks—the single highest mark allocation for any individual question on the exam. This is disproportionate: an Inferential question asking 'Why do you think... ?' typically warrants 3–4 marks for Grade 6. By contrast, Q1.2 (a direct quote requiring precise recall) is allocated only 2 marks. The distribution is top-heavy on this one question.
- **Qmemo:2 — memoAccuracy**: Memo Q2 lists '(6) Small actions such as turning off taps and collecting rainwater can help save water.' and '(7) If we waste water today, future generations will suffer.' These are valid key points traceable to the passage. However, the rubric allocates 5 marks for up to 5 distinct key points, but the suggested answer lists 7 possible points. A teacher may award more than the allocated marks if a learner extracts points 6 and 7. This creates ambiguity.

---

### What we want from your review

1. Open the DOCX file. Read it as if you received it from a colleague.
2. Would you publish it for your class as-is? With minor edits? Not at all?
3. Look at the AI moderator's verdict above. Does it match your judgement?
   - If the AI said PASS but you would NOT publish: what did it miss?
   - If the AI flagged BLOCKING issues but you would publish anyway: which flags are pedantic?
4. Are there ANY pedagogical issues the AI didn't catch?
