# g6-afrikaans-home-language-test-t3

**AI moderator verdict:** NEEDS_WORK  |  **score:** 3/5  |  **version:** original

## AI recommendation

The paper has solid pedagogical design and covers the curriculum topics well, with a logical progression from literal comprehension through to creative writing. However, there are multiple blocking issues that must be addressed before publication. The most critical problem is a language register mismatch: the entire test is presented in English (instructions, stems, questions) for a Grade 6 Afrikaans Home Language assessment, which violates CAPS principles and creates an unfair cognitive burden on learners. Additionally, the subject line in the meta data and cognitive framework allocation are inconsistent with actual marks, and a key cognitive level mislabeling exists in Question 3.5. The paper also lacks critical formatting details (no rubric for Q4 marks breakdown and no extension activity link) and has minor marking guidance gaps. These issues are fixable with targeted regeneration, but the language register violation must be resolved as the first priority.

## Dimension scores (1-5)

| Dimension | Score | Notes |
|---|---|---|
| memoAccuracy | 4/5 | Memo answers are factually correct and evidence-based. All arithmetic checks out (mark totals, word counts). Marking guidance is generally actionable, though Q4 rubric lacks explicit mark allocation per criterion (3+2+1=6 marks claimed but paper allocates 4 marks to Q4, creating a discrepancy). |
| cognitiveLevelIntegrity | 3/5 | Most labels match actual demands correctly (e.g., 1.1 Literal, 1.5 Inferential, 2.5 Evaluation). However, Q3.5 is mislabeled: the stem 'Combine sentences using a suitable conjunction' is a Reorganisation-level procedural task, not Inferential; the cognitive demand is rote application of grammar rules, not inference. |
| topicAlignment | 4/5 | All questions align with stated topics. Q1 tests comprehension of folk tale; Q2 tests visual text analysis and language structures; Q3 systematically tests conjunctions and relative clauses; Q4 tests creative composition in Afrikaans. No topic drift detected. |
| markFairness | 3/5 | Marks are generally proportional (1 mark for recall, 2-3 for short multi-part answers, 5 for inference with evidence). However, Q4 is undermarked: creative composition spanning 100–120 words with three paragraphs and a rubric is allocated only 4 marks out of 40 total, while a short 5-line inference (Q1.5) earns 5 marks. The rubric itself totals 6 marks (3+2+1) but the question is worth 4 marks—an internal inconsistency. |
| mcqQuality | 5/5 | No MCQ questions present in this paper; criterion not applicable. |
| questionClarity | 3/5 | Most stems are clear and unambiguous in structure. However, the entire paper is written in English for an Afrikaans Home Language test, creating a severe clarity and fairness issue. Additionally, Q2.2 ('By when must learners register, and where must they register?') is a double-barrelled question conflating two separate pieces of information, though the stimulus makes both available. |
| stimulusQuality | 4/5 | Both stimuli (folk tale passage and advertisement) are coherent, age-appropriate, and internally consistent. The passage (210 words) is suitable for Grade 6 and logically structured. The visual text description is detailed enough to answer questions. All stimulus references resolve correctly. |
| capsCompliance | 2/5 | Cover page is present with correct fields (name, surname, date, examiner, time, total marks). Sections are ordered from easier (literal comprehension) to harder (creative writing), which is correct. However, a critical CAPS violation exists: the meta field lists subject as 'Afrikaans Home Language' but language as 'English', and all instructions and question stems are in English. CAPS requires that Afrikaans Home Language assessment be conducted in Afrikaans. The instructions do not align with the resourceType 'Test' (which should be 'Assignment' for a 40-mark creative writing component) and the extension activity (drama scene) is mentioned but not marked or formally integrated into the main paper. |
| languageRegister | 2/5 | This is the most critical issue. The entire paper (cover, instructions, section headings, question stems) is in English, whereas a Grade 6 Afrikaans Home Language assessment must be conducted in Afrikaans. The rubric and marking guidance are also in English. This violates CAPS language policy and creates an unfair dual-language cognitive burden on learners. The stimuli (folk tale and advertisement) are correctly in Afrikaans, which creates a jarring mismatch. Grade 6 register is otherwise appropriate, but the language choice undermines the entire assessment. |
| biasSensitivity | 4/5 | Names and contexts are SA-appropriate ('Juffrou Botha', school library reference). Gender stereotyping is absent. Socioeconomic assumptions are minimal, though the advertisement assumes access to school library facilities (which is reasonable for a school-based test). No obvious bias detected, but limited diversity in character names. |
| culturalContext | 5/5 | Both stimuli are culturally contextualised to SA. The folk tale is a traditional form; the advertisement references school library registration, which is familiar to the target audience. Currency, places, and terminology are SA-appropriate (August for school term, school library, typical school activities). |
| curriculumCoverage | 4/5 | The paper addresses the stated topics well: folk tale comprehension (Lees en Kyk), visual text analysis, language structures (saamgestelde sinne, betreklike bysinne, leestekens), and creative writing. Term 3 content is represented. However, the topicScope claims to include 'Mondeling: mondelinge aanbieding van projek (20 punte)' but this is not assessed in the written paper—it is mentioned only in the extension activity, creating a curriculum coverage gap. |

## BLOCKING issues (4)

- **Qcover — languageRegister**
  - Issue: The entire test paper—including cover page, instructions, section headings, and all question stems—is written in English, whereas this is a Grade 6 Afrikaans Home Language assessment. CAPS policy requires that Afrikaans Home Language assessments be conducted in the target language (Afrikaans). The passage and advertisement stimuli are in Afrikaans, creating a jarring and cognitively unfair mismatch. Learners must translate or switch language constantly.
  - Suggested fix: Regenerate the entire paper in Afrikaans. Translate cover page, instructions (e.g., 'Beantwoord alle vrae in al drie afdelings'), section headings (e.g., 'BEGRIPSTOETS: VOLKSVERHAAL'), and all question stems into idiomatic Afrikaans. Preserve the Afrikaans stimuli and maintain pedagogical structure.

- **Q3.5 — cognitiveLevelIntegrity**
  - Issue: Question 3.5 is labelled 'Inferential' but the stem—'Combine the following sentences into ONE sentence using a suitable conjunction'—demands a Reorganisation-level procedural task (applying a grammar rule to combine sentences). Inferential cognition requires making inferences beyond explicit text, not applying a mechanical grammar rule. This mislabeling violates cognitive level integrity and misallocates marks.
  - Suggested fix: Relabel Q3.5 as 'Reorganisation', not 'Inferential'. The cognitive demand is structural manipulation, not inferential reasoning.

- **Q4 — markFairness**
  - Issue: Question 4 (creative folk tale writing) is allocated only 4 marks out of 40 total (10% of the paper), yet the rubric provided shows three criteria totalling 3+2+1=6 marks. This is an internal inconsistency. Additionally, a 100–120 word composition with three paragraphs covering character, problem, solution, and moral lesson is undermarked relative to the effort demanded: Q1.5 (a 5-line inference response) earns 5 marks; Q4 (a multi-paragraph composition) earns only 4. This violates mark fairness principles.
  - Suggested fix: Either: (A) Increase Q4 marks to at least 6 marks and align the rubric explicitly (e.g., Content 3, Language 2, Mechanics 1 = 6 total), OR (B) Restructure the rubric to fit 4 marks clearly (e.g., Content 2, Language 1, Mechanics 1). Recommend option (A) for fair assessment of extended composition.

- **QcapsCompliance — capsCompliance**
  - Issue: The meta field declares subject='Afrikaans Home Language' but language='English', and resourceType='Test' (implying a short assessment) while also listing a 40-mark 'kreatiewe skryfprojek' (creative writing project) which CAPS typically separates from tests. Additionally, the extension activity (drama scene in Afrikaans) is mentioned in the memo but not formally included in the main paper or marked. This violates CAPS structural compliance and creates confusion about assessment boundaries.
  - Suggested fix: Clarify the assessment type: if the creative writing is a separate project (40 marks, as suggested by topicScope), separate it into its own resource document. If it is part of a single test, adjust resourceType, totalMarks, and meta alignment. Formally integrate or remove the extension activity, and ensure all instructions match the meta declaration.

## Advisory issues (2)

- **Q2.2 — questionClarity**: Question 2.2 asks 'By when must learners register, and where must they register?' This is a double-barrelled question conflating two distinct pieces of information (deadline + location). While the stimulus contains both answers, the question stem should ask for them separately or clearly. The marking guidance expects both answers for full marks, but the stem phrasing is ambiguous about whether both are required.
- **Qmemo:4 — memoAccuracy**: The rubric for Q4 states marks as (3+2+1=6) but the question header allocates only 4 marks. The marking guidance says 'Use the provided rubric' but does not clarify how 6 rubric marks map to 4 allocated marks. This creates ambiguity for teacher application and potential inconsistency in marking.

---

### What we want from your review

1. Open the DOCX file. Read it as if you received it from a colleague.
2. Would you publish it for your class as-is? With minor edits? Not at all?
3. Look at the AI moderator's verdict above. Does it match your judgement?
   - If the AI said PASS but you would NOT publish: what did it miss?
   - If the AI flagged BLOCKING issues but you would publish anyway: which flags are pedantic?
4. Are there ANY pedagogical issues the AI didn't catch?
