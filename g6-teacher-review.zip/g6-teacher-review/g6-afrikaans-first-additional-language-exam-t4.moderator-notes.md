# g6-afrikaans-first-additional-language-exam-t4

**AI moderator verdict:** NEEDS_WORK  |  **score:** 3/5  |  **version:** original

## AI recommendation

This paper is publishable with targeted fixes. Strengths: excellent stimulus quality (coherent, SA-contextualised, age-appropriate); no memo arithmetic errors; strong MCQ design; balanced bias and cultural sensitivity; good topic coverage. Weaknesses: (1) critical mark allocation discrepancy in Q2 (2 marks in memo vs. 5 in exam instructions) — BLOCKING, must be resolved before release; (2) Q1.6 appears over-marked (7 marks) relative to similar Inferential questions; (3) three questions (5.2, 7.3, and borderline 1.4) have cognitive level labels that do not match actual demand, creating confusion for teachers marking and learners understanding. These issues are fixable with a targeted regen pass focusing on mark reconciliation and cognitive level alignment, without requiring full paper regeneration.

## Dimension scores (1-5)

| Dimension | Score | Notes |
|---|---|---|
| memoAccuracy | 4/5 | Memo answers are factually correct and well-reasoned. Marking guidance is clear and actionable for most questions. One minor issue: Question 2 memo says 2 marks but the question specifies '5 marks — one mark per valid point'; the memo should align with this allocation. |
| cognitiveLevelIntegrity | 3/5 | Most labels match actual demands, but there are inconsistencies. Q1.4 'Explain in your own words' is labelled Reorganisation but requires restating the author's meaning (Literal/Reorganisation borderline). Q5.2 asks 'Identify AND give reason' but is labelled Inferential — identification is Literal; only the reasoning involves inference. Q7.3 asks to identify a compound sentence, which is Literal/Reorganisation, not Inferential. |
| topicAlignment | 4/5 | All questions align well with stated topics. Questions test water content knowledge, visual literacy, and Afrikaans language structures as promised in the topic scope. |
| markFairness | 3/5 | Most marks are fair (1 mark for single-word recall, 2 marks for short calculation or combined task). However, Q1.6 (7 marks for a single extended inference about Cape Town example) seems high relative to Q1.7 (3 marks for a broader climate-change inference). The 2-mark allocation for Q2 (summary) contradicts the exam instructions stating '5 marks — one mark per valid point.' |
| mcqQuality | 4/5 | All MCQs (7.1–7.3) have exactly one correct answer and plausible distractors. Grammar is parallel. Q7.1 distractors ('koude', 'kouds', 'kolds') test understanding of adjective agreement well. No structural issues. |
| questionClarity | 4/5 | Most questions are clear and unambiguous. Vocabulary is appropriate for Grade 6 FAL learners. Q5.2 asks to 'Identify the part of speech AND give a reason' — technically two demands but they are tightly linked (standard practice for language analysis). No major clarity issues. |
| stimulusQuality | 5/5 | Both stimuli are high-quality. The non-literary passage on water is coherent, age-appropriate, 230 words (reasonable length), and grounded in South African context (Cape Town, Day Zero, Department of Water and Sanitation). The poster description is detailed enough for learners to answer visual analysis questions without seeing the actual image. |
| capsCompliance | 4/5 | Cover page is complete with all required fields (name, surname, date, examiner, time, total marks, instructions). Sections are ordered with lower cognitive demand first (Literal/Reorganisation in Sections A–B, Inferential/Evaluation in later questions). However, the total mark discrepancy in Q2 creates a structural issue: exam instructions say 50 marks total, section D claims 7 marks (7.1–7.3), but Q2 memo says 2 marks vs. 5 marks stated in exam text. |
| languageRegister | 4/5 | English section headers and instructions are clear and appropriately pitched. Afrikaans language questions (4.1–7.3) use standard, grammatically correct Afrikaans appropriate for Grade 6 FAL. No spelling or grammar errors detected. Note: assessment is of English register only; Afrikaans content flagged as ADVISORY where uncertain. |
| biasSensitivity | 5/5 | No gender, racial, or socioeconomic stereotyping detected. Names in Afrikaans examples ('die vrou', 'die leerder', 'die kinders') are generic. Water conservation is framed as a universal responsibility, not tied to any particular community. |
| culturalContext | 5/5 | Excellent SA cultural grounding. Stimuli include Cape Town, Department of Water and Sanitation (real government body), South African water scarcity, and local examples. Language section uses Afrikaans-specific grammar structures (double negation, relative pronouns). Highly contextually appropriate for Grade 6 learners in SA. |
| curriculumCoverage | 4/5 | Good coverage of Terms 3–4 topics: non-literary text (Section A), summary (Section B), visual text (Section C), and language structures including compound sentences, relative clauses, tenses, and parts of speech (Section D). One area underrepresented: creative writing is not tested (the topic scope mentions 'kreatiewe skryfprojek' but this exam is comprehension-focused, which aligns with 'Eindeksamen' notation). |

## BLOCKING issues (1)

- **Q2 — markFairness**
  - Issue: Question 2 (Summary) is marked as 2 marks in the memo, but the exam instructions for Section B explicitly state: '(5 marks — one mark per valid point.)' The discrepancy creates ambiguity about actual mark allocation. The rubric in the memo does not address Question 2 separately, only Questions 1.8 and 3.4.
  - Suggested fix: Correct the memo entry for Question 2 to '5 marks' (one per valid point: global freshwater scarcity, SA water challenge, major non-drinking use, individual action, government action). Alternatively, revise the exam instruction for Section B to state '2 marks' if a shorter summary is intended, and adjust the rubric guidance to clarify which points attract marks.

## Advisory issues (4)

- **Q1.6 — markFairness**: Question 1.6 (Why was Cape Town example included? What effect?) is allocated 7 marks, while Q1.7 (Infer relationship between climate change and water crisis) is allocated 3 marks. Both are Inferential, single-question extended responses. The 7-mark allocation for Q1.6 seems disproportionately high relative to other Inferential questions and to the effort required (both ask for reasoning and explanation).
- **Q5.2 — cognitiveLevelIntegrity**: Question 5.2 asks to 'Identify the part of speech AND give a reason.' The 'identify' component is Literal (recall/recognise), but the labelled cognitive level is Inferential. This is a mismatch: identification alone is not inferential; only the reasoning component (explaining why it's an adjective) requires inference.
- **Q7.3 — cognitiveLevelIntegrity**: Question 7.3 asks learners to identify which sentence is a compound sentence (saamgestelde sin). This is pattern recognition / classification of a grammatical term — Literal or Reorganisation, not Inferential. The labelled level is Inferential, which overstates the cognitive demand.
- **Q1.4 — cognitiveLevelIntegrity**: Question 1.4 asks learners to 'Explain in your own words what the writer means by 'every drop counts.' This is a restating/paraphrasing task (reorganising the writer's implicit meaning), but it is labelled Reorganisation. However, it sits at the borderline between Reorganisation (restating what is said) and Literal (if the phrase is explicitly defined). The labelling is defensible but lean.

---

### What we want from your review

1. Open the DOCX file. Read it as if you received it from a colleague.
2. Would you publish it for your class as-is? With minor edits? Not at all?
3. Look at the AI moderator's verdict above. Does it match your judgement?
   - If the AI said PASS but you would NOT publish: what did it miss?
   - If the AI flagged BLOCKING issues but you would publish anyway: which flags are pedantic?
4. Are there ANY pedagogical issues the AI didn't catch?
