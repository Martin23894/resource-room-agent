# g6-afrikaans-home-language-test-t1

**AI moderator verdict:** NEEDS_WORK  |  **score:** 3/5  |  **version:** original

## AI recommendation

This is a well-structured, culturally relevant Afrikaans Home Language test with strong stimulus quality, clear alignment to CAPS topics, and good cognitive diversity across Barrett's levels. However, three critical fairness issues require targeted remediation: (1) Question 2.4 carries 8 marks for an Inferential question, which is severely over-weighted and distorts the cognitive weighting (Inferential should be ~40% of marks = 16 total, but this single question accounts for half that). (2) Question 4 (extended write) carries only 4 marks, underweighting composition relative to short-answer tasks. (3) Supporting memo entries (Q2.2, Q3.2, Q3.3) contain ambiguities or contradictions that will lead to inconsistent marking in school. These are fixable with a targeted regen pass: reduce Q2.4 to 3 marks, increase Q4 to 6–8 marks, and tighten memo guidance on syllable division, spelling variants, and quote marking. The paper will then be publication-ready.

## Dimension scores (1-5)

| Dimension | Score | Notes |
|---|---|---|
| memoAccuracy | 3/5 | Most memo answers are accurate, but question 2.4 allocates 8 marks without a proportionate answer model, and 3.3 has potential syllable variation issues that are marked loosely. |
| cognitiveLevelIntegrity | 3/5 | Most questions match their labelled levels, but question 2.4 is labelled Inferential (8 marks) yet demands significant inferential development for a Grade 6 learner—the mark allocation feels inflated for the cognitive load. |
| topicAlignment | 4/5 | Each question's topic statement aligns with the content tested. Minor issue: question 4 conflates writing and presentation skills but does address 'Skryf en Aanbied' as labelled. |
| markFairness | 2/5 | Question 2.4 (8 marks) is severely over-marked for an Inferential question; most Inferential questions in Grades 4–7 carry 3–4 marks. The writing task (Q4, 4 marks) is also light for extended composition. |
| mcqQuality | 5/5 | No MCQ questions in this paper; score is NA. Marked 5 as no structural defect. |
| questionClarity | 4/5 | Stems are clear and unambiguous. Q1.6 and Q1.7 are slightly double-barrelled ('Why…What does this tell us') but intent is clear in context. |
| stimulusQuality | 4/5 | Both passages are coherent, age-appropriate, and resolve correctly. Newspaper passage (110 words) is well-written. Novel extract (120 words) is engaging and suitable for Grade 6. |
| capsCompliance | 4/5 | Cover page complete with all required fields. Sections are ordered (A–D: low to high cog level, though Section C jumps between Reorganisation and Inferential). Cognitive framework (Barrett's) is correctly declared. |
| languageRegister | 3/5 | English instructions and memo are grammatically correct. Afrikaans passages are naturalistic and age-appropriate for Grade 6. Minor advisory: memo answers sometimes mix Afrikaans/English without signal; stems use English only (appropriate for English-medium test instructions). |
| biasSensitivity | 4/5 | Names reflect SA diversity (Dlamini, Daan, Faan). No gender/racial/socioeconomic stereotyping detected. Water-saving context is inclusive and relevant to SA. |
| culturalContext | 5/5 | Paper is strongly SA-contextualised: Hoërskool Sonneblom, provincial competition, R50 000 grant, WaterSmart SA, water shortage context. Novel setting is unspecified but plausible in SA. |
| curriculumCoverage | 4/5 | Paper covers reading (comprehension), literature (novel extract), language structures (punctuation, spelling, syllables, dictionary), and writing. Good spread of Term 1 topics; poetry and drama are deferred to Term 2 as stated in scope. |

## BLOCKING issues (2)

- **Q2.4 — markFairness**
  - Issue: Question 2.4 is labelled 'Inferential' and carries 8 marks — nearly 20% of the total paper mark. The stem asks learners to infer why Oupa Faan expected Daan and what this suggests about the plot. While a valid Inferential question, 8 marks is disproportionate for a Grade 6 extended inference; typical Inferential questions in CAPS-aligned tests carry 3–4 marks. This inflates the mark allocation and privileges a single cognitive skill. The memo guidance ('Accept any reasonable, text-supported inference') compounds the fairness issue by offering little scaffolding for consistent marking across different scripts.
  - Suggested fix: Reduce question 2.4 to 3 marks (consistent with other Inferential questions in the paper, e.g. Q1.6). Alternatively, split the inferential demand into two separate questions (Why Oupa expected Daan = 2 marks; what this suggests about plot = 2 marks). Provide more detailed rubric guidance in the memo (e.g. 'Award 1 mark for identifying that Oupa has prior knowledge; 1 mark for connecting this to family/mystery; 1 mark for suggesting Daan will uncover a secret').

- **Q4 — markFairness**
  - Issue: Question 4 is a newspaper report writing task (80–100 words) carrying only 4 marks — the same as question 2.4 (an Inferential short-answer). Writing an extended report with headline, school name, event description, direct quote, and time/place details requires significant planning, composition, and proofreading effort. Four marks for this is underweighted; CAPS guidelines and Grade 6 best practice suggest 6–8 marks for an extended write. The rubric provided is also underdeveloped (single criterion, five levels), making it difficult for teachers to award marks fairly across multiple dimensions (accuracy, content, structure, language use).
  - Suggested fix: Increase Q4 to 6–8 marks. Expand the rubric to include separate criteria: e.g. (1) Content & Structure (all required elements; 2 marks); (2) Language & Spelling (vocabulary, grammar, punctuation; 2 marks); (3) Presentation & Legibility (1 mark). Provide sample 'band descriptors' (e.g. 'Band 1: All elements present, well-structured, clear language' = 6 marks; 'Band 2: Most elements, mostly clear' = 4 marks). Rebalance total marks so extended writing carries proportional weight.

## Advisory issues (4)

- **Q3.2 — memoAccuracy**: Question 3.2 has two spelling options. The memo lists 'entoesiasties' (adjective form) and 'stadigaan' as correct. However, the second sentence reads 'Hy het die skuur se deur __________ oopgemaak' (He made the barn door _____ open). The word 'stadigaan' appears in the novel passage as 'stadig oopgekraak' (slowly creaked open), suggesting 'stadig' (slowly, adverb) is the expected answer, not the compound 'stadigaan' (which is non-standard Afrikaans). The memo should clarify: does 'stadigaan' exist as a single word, or should the expected answer be 'stadig'? This risks inconsistent marking.
- **Q3.3 — memoAccuracy**: Question 3.3 asks learners to divide three words into syllables. The memo provides one possible division for each (e.g. 'wa-ter-be-spa-rings'). However, Afrikaans syllable division can vary slightly based on morphological vs. phonological principles. The memo states 'Accept minor variations as long as natural Afrikaans syllable breaks are respected,' but does not provide explicit criteria for what counts as 'natural.' For example, 'waterbesparings' could reasonably be divided as 'wa-ter-be-spa-rings' or 'wa-ter-bes-pa-rings' depending on whether the root-morpheme boundary (bespar-) or phonetic flow is prioritised. Without clearer guidance, teachers may mark inconsistently.
- **Q1.7 — questionClarity**: Question 1.7 has a slightly double-barrelled structure: 'Do you think projects like this one are important for South Africa? Give TWO reasons to support your answer.' The first sentence asks for opinion (Yes/No); the second demands justification. Most Grade 6 learners will navigate this, but it could be clearer. A learner might answer 'Yes, I think they are important' and then provide two reasons, but a weaker reader might interpret the question as asking only for agreement/disagreement without reasons, leading to partial-credit disputes.
- **Q2.2 — memoAccuracy**: Question 2.2 asks for a quote showing Daan was frightened. The memo lists two acceptable quotes and states '[Marks awarded: 1 mark] Per correct quoted phrase, up to 2 marks.' This creates confusion: the question is worth 1 mark (as stated in the question header), but the memo says 'up to 2 marks.' Teachers may be unsure whether to award 0.5 marks per phrase or insist on both quotes for full mark, or accept one for full mark. The guidance is contradictory.

---

### What we want from your review

1. Open the DOCX file. Read it as if you received it from a colleague.
2. Would you publish it for your class as-is? With minor edits? Not at all?
3. Look at the AI moderator's verdict above. Does it match your judgement?
   - If the AI said PASS but you would NOT publish: what did it miss?
   - If the AI flagged BLOCKING issues but you would publish anyway: which flags are pedantic?
4. Are there ANY pedagogical issues the AI didn't catch?
