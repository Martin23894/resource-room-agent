# g6-english-first-additional-language-test-t3

**AI moderator verdict:** NEEDS_WORK  |  **score:** 3/5  |  **version:** original

## AI recommendation

This is a well-structured, coherent Grade 6 English FAL assessment with strong stimulus quality, cultural grounding, and CAPS compliance. Passages are engaging and age-appropriate; reading and language items are clearly designed and fairly graded overall. However, THREE mark-allocation errors (questions 3.1, 4.1, and clarity around 3.1 demand) and one cognitive-level mislabel (3.4) must be resolved before publication. These are fixable with targeted revision: clarify and reweight questions 3.1 and 4.1; relabel 3.4 cognitive level; and tighten memo guidance on acceptable answer variants. No factual or conceptual errors in content; no bias or sensitivity issues detected. Recommend NEEDS_WORK with targeted fixes to mark fairness and question labelling, then resubmit.

## Dimension scores (1-5)

| Dimension | Score | Notes |
|---|---|---|
| memoAccuracy | 4/5 | Most answers are correct and actionable, but question 3.1 memo contains a logical error: the answer keys 'both' as correct, but learners writing either version (subordinate clause at start or end) should both receive full marks—this needs clarification in marking guidance. |
| cognitiveLevelIntegrity | 4/5 | Overall alignment is strong. Question 3.4 (write a sentence with 'which') is labelled Inferential but actually tests Routine Procedures (apply the rule). This is a minor mismatch but represents one question out of ~30. |
| topicAlignment | 4/5 | Questions align well with stated topics. All reading/comprehension questions match report and folktale content; language questions address complex sentences and punctuation; oral and writing sections address stated scope. |
| markFairness | 3/5 | Most allocations are reasonable, but question 3.1 awards only 1 mark for combining TWO pairs of sentences—this should be 2 marks (1 per pair). Question 4.1 awards 2 marks for punctuating 3 sentences, which is light (should be 3 marks, or 2 marks per sentence). Mark balancing is slightly skewed. |
| mcqQuality | 5/5 | All MCQ items (1.7, 4.2, 5.1) have exactly one correct answer, plausible distractors, and parallel grammar. Distractors are appropriately credible for Grade 6. |
| questionClarity | 4/5 | Questions are generally clear and fit Grade 6 vocabulary. Question 3.1 stem includes TWO pairs but labels the marks as '1'—ambiguous whether both or one is assessed. Question 4.1 similarly presents 3 sentences but marks field says 2 marks, creating uncertainty. |
| stimulusQuality | 5/5 | Both passages (report and folktale) are well-written, age-appropriate, coherent, and realistic in length. Word counts match metadata (220 and 255). All references in questions resolve correctly to the stimuli. |
| capsCompliance | 5/5 | Cover page is complete with all learner info fields and instructions. Sections progress from lower to higher cognitive demand (A/B Literal-to-Evaluation; C Language; D Oral/Writing). Structure follows CAPS RTT framework for First Additional Language. |
| languageRegister | 5/5 | English is grammatically correct throughout, with vocabulary and register appropriate for Grade 6 FAL. Passages read fluently and stems are clear. No spelling errors detected. |
| biasSensitivity | 5/5 | No gender, racial, or socioeconomic stereotyping detected. Names reflect SA context (Riverside Primary School, Limpopo River, WaterAid partnership); examples are inclusive and relatable. |
| culturalContext | 5/5 | Strong SA cultural grounding: water crisis in rural South Africa, WaterAid's work locally, Southern African folktale (Limpopo River setting), Riverside Primary School. Age-appropriate and locally resonant. |
| curriculumCoverage | 4/5 | Good coverage of reading (non-literary/report + folklore), language (complex sentences, relative clauses, punctuation), oral and writing skills. However, 'creative writing project' mentioned in topicScope (40 marks) is not fully assessed—only brief paragraph starter (4 marks). Coverage is broad but creative writing depth is thin. |

## BLOCKING issues (2)

- **Q3.1 — markFairness**
  - Issue: Question asks learners to 'Combine the following pairs of simple sentences' (a) and (b)—that is, TWO separate tasks. Yet marks field shows only 1 mark total. Additionally, memo shows both orders of subordination are acceptable (e.g., 'The learners studied hard because they passed' AND 'Because the learners studied hard, they passed'), implying 2 acceptable answers per pair. This creates confusion: is 1 mark for both pairs? 1 mark for one pair? The guidance is ambiguous.
  - Suggested fix: Clarify: either (i) change marks to 2 (one per pair, or 0.5 per correct sentence), and revise memo marking guidance to state 'Award 1 mark per correctly formed complex sentence (up to 2 marks)', OR (ii) simplify to ask for only ONE pair to combine and keep 1 mark. Most straightforward: change marks from 1 to 2 and update guidance: '[Marks awarded: 2 marks] Award 1 mark for each correctly combined sentence (a) and (b). Accept both subordinate-initial and subordinate-final word orders.'

- **Q4.1 — markFairness**
  - Issue: Question stem states 'Rewrite the following sentences' and then presents THREE sentences (a), (b), and (c) to punctuate. However, marks field shows only 2 marks total. This is under-weighted for three separate punctuation tasks. Memo also lists three correct answers but does not clarify the mark split.
  - Suggested fix: Change marks from 2 to 3 (one mark per sentence), and revise memo guidance to: '[Marks awarded: 3 marks] Award 1 mark for each correctly punctuated sentence. Sentence must include correct capitals, full stops, commas, and apostrophes as needed.' Alternatively, if assessment intent is only 2 marks, select and present only TWO sentences to rewrite.

## Advisory issues (3)

- **Q3.4 — cognitiveLevelIntegrity**: Question 3.4 is labelled Inferential ('Write your own complex sentence using the relative pronoun 'which''), but the task requires learners to apply/produce a relative clause sentence—a Routine Procedures skill (apply a learned structure). Inferential would involve interpreting or deducing meaning, not constructing a new example. This is a one-question mismatch and does not distort the paper's overall cognitive balance (Inferential still has sufficient items), but the label is inaccurate.
- **Q3.1 — questionClarity**: The stem groups two distinct sentence-combining tasks under (a) and (b) without explicitly signalling how many marks are assigned to each, or whether learners should complete both. While context suggests both are required, the phrasing could be clearer for Grade 6 learners unfamiliar with composite question conventions.
- **Qmemo:3.1 — memoAccuracy**: Memo answer for 3.1 presents two correct versions for sentence (a): 'The learners studied hard because they passed the test' and 'Because the learners studied hard, they passed the test.' Both are grammatically acceptable, which is good. However, marking guidance does not explicitly state that BOTH word orders earn full credit, risking inconsistent teacher application (some may penalise 'incorrect' order). This should be explicit.

---

### What we want from your review

1. Open the DOCX file. Read it as if you received it from a colleague.
2. Would you publish it for your class as-is? With minor edits? Not at all?
3. Look at the AI moderator's verdict above. Does it match your judgement?
   - If the AI said PASS but you would NOT publish: what did it miss?
   - If the AI flagged BLOCKING issues but you would publish anyway: which flags are pedantic?
4. Are there ANY pedagogical issues the AI didn't catch?
