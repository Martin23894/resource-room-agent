# g6-afrikaans-first-additional-language-test-t1

**AI moderator verdict:** NEEDS_WORK  |  **score:** 3/5  |  **version:** original

## AI recommendation

This paper is **NEEDS_WORK**: fixable with targeted regen. Three BLOCKING cognitive level mismatches (Q1.4, Q5.2, Q4.3) significantly undermine the paper's assessment integrity. These mislabellings will create confusion for teachers calibrating question difficulty and for learners understanding the progression of cognitive demand across the paper. All three corrections are straightforward label changes. One ADVISORY flag on mark fairness (Q5.2 over-marked) and one on distractor plausibility (Q3.2) are minor refinements. Stimulus quality, language register, cultural context, and memo accuracy are sound. Recommend a focused regen pass to correct the three cognitive level labels, then resubmit for verification.

## Dimension scores (1-5)

| Dimension | Score | Notes |
|---|---|---|
| memoAccuracy | 4/5 | Memo answers are factually sound and well-referenced to the stimulus texts. Marking guidance is clear and actionable, with rubric for extended writing provided. Minor ambiguity on mark allocation for 5.2 (SMS), but no arithmetic errors detected. |
| cognitiveLevelIntegrity | 2/5 | Multiple mislabellings of cognitive levels detected. Q1.4 is labelled Inferential but is Literal (directly stated: 'suidoosterwind'). Q5.2 is labelled Evaluation/Appreciation but is Reorganisation/Routine Procedures (apply SMS format). Q4.3 (dictionary guide words) is labelled Inferential but is Reorganisation. Cumulative: 3 errors = BLOCKING. |
| topicAlignment | 4/5 | Questions align well with stated topics. All comprehension, visual literacy, and language structure questions match their topic labels. Writing tasks are consistent with 'Skryf en Aanbied' topics. |
| markFairness | 3/5 | Overall mark distribution reasonable, but Q5.2 (SMS, 3 marks) is over-marked given minimal effort required vs Q1.5 (3 marks for a substantive response). Q4.2 (simple rewrite with punctuation) at 2 marks is fair but Q4.3 (single-word answer) at 1 mark is fair. Total: 40 marks distributed across 5 sections is proportional. |
| mcqQuality | 5/5 | No MCQ items in this paper; not applicable. |
| questionClarity | 4/5 | Questions are generally clear and unambiguous. Bilingual stems aid accessibility. Q3.2 (verb conjugation) is clear. Minor: Q1.4 could be clearer about whether learner must explain mechanism or just identify cause (memo answers both). Q4.3 (dictionary guide words) is clear. |
| stimulusQuality | 5/5 | Newspaper report (118 words) is age-appropriate, coherent, and directly relevant to Grade 6 FAL curriculum. Visual text description is detailed and sufficient. No missing references; all stimuli invoked in section instructions. |
| capsCompliance | 4/5 | Cover page complete with all required fields (name, surname, date, examiner, time, total). Sections A–D progress from comprehension (lower) to writing (higher cognitive demand). Minor: Section structure is RTT-like but subject is FAL (not HL), so strict RTT ordering (passage + comprehension → summary → language + visual) is advisory, not mandatory. Paper meets CAPS structural expectations for FAL. |
| languageRegister | 4/5 | English instructions are clear and age-appropriate. Afrikaans text and questions are idiomatic; no obvious literal translation errors. Newspaper report and poster description use natural Afrikaans. Minor: 'spelen' in Q3.2(a) is not standard Afrikaans (should be 'speel' in both finite and infinitive contexts); memo marks 'speel' correct, which is right. |
| biasSensitivity | 5/5 | No stereotyping detected. Firefighters not gendered. Victims include a named male (Jan Visser) and multi-gender family units. Cape Town setting is diverse. No socioeconomic assumptions. Names reflect South African context. |
| culturalContext | 5/5 | Stimulus contexts are strongly South African: Table Mountain, Cape Town, South African organisations (Rooi Kruis / Red Cross). Relevant to Grade 6 in a multilingual, urban SA context. No Eurocentric assumptions. |
| curriculumCoverage | 4/5 | Paper covers Term 1 topics: reading comprehension (newspaper report, visual text), language structures (nouns, pronouns, tenses, punctuation, dictionary skills), and writing (summary, SMS, narrative). Good spread across curriculum. Minor: Q3.1(d) abstract noun (vrede) is isolated example; could be reinforced. Overall coverage is sound. |

## BLOCKING issues (3)

- **Q1.4 — cognitiveLevelIntegrity**
  - Issue: Question 1.4 is labelled 'Inferential' but it tests 'Literal' comprehension. The stem asks 'Why did the fire spread so quickly?' and the answer is directly stated in the passage: 'het vinnig versprei as gevolg van die sterk suidoosterwind' (spread quickly due to the strong south-easterly wind). No inference beyond the text is required; the learner merely locates and restates explicit information. This misalignment will confuse teachers calibrating assessment difficulty.
  - Suggested fix: Change cognitive level to 'Literal' for Q1.4.

- **Q5.2 — cognitiveLevelIntegrity**
  - Issue: Question 5.2 is labelled 'Evaluation and Appreciation' but the task actually requires 'Reorganisation' or 'Routine Procedures'. The learner is asked to write an SMS in a specific, familiar register summarising key information from the stimulus. This is application of a standard format, not evaluation or critical appreciation. The cognitive demand does not match the label.
  - Suggested fix: Change cognitive level for Q5.2 to 'Reorganisation'.

- **Q4.3 — cognitiveLevelIntegrity**
  - Issue: Question 4.3 is labelled 'Inferential' but tests 'Reorganisation' (or simple alphabetisation skill). The learner applies a concrete, rule-based alphabetical ordering rule to determine which word falls between two guide words. This is procedural recall/application, not inference. No reading beyond the text or reasoning about meaning is required.
  - Suggested fix: Change cognitive level for Q4.3 to 'Reorganisation'.

## Advisory issues (2)

- **Q5.2 — markFairness**: Question 5.2 (SMS, 3 marks) appears over-marked relative to the cognitive demand. An SMS is a familiar, brief format (2–3 sentences) requiring minimal elaboration. By contrast, Q1.5 (feel + evidence, 3 marks) requires substantive textual analysis and evidence integration. The 3-mark allocation for Q5.2 is generous given the task simplicity.
- **Q3.2 — questionClarity**: In Q3.2(a), the option 'spelen' appears as a distractor alongside 'speel'. However, 'spelen' is not standard Afrikaans for any conjugation of 'speel' (to play). It resembles Dutch 'spelen', which may confuse learners exposed to related languages. The memo correctly marks 'speel' as the answer, but the distractor is not a plausible Afrikaans error—it would be more effective to use a common learner error (e.g. 'spele' or 'gespeel').

---

### What we want from your review

1. Open the DOCX file. Read it as if you received it from a colleague.
2. Would you publish it for your class as-is? With minor edits? Not at all?
3. Look at the AI moderator's verdict above. Does it match your judgement?
   - If the AI said PASS but you would NOT publish: what did it miss?
   - If the AI flagged BLOCKING issues but you would publish anyway: which flags are pedantic?
4. Are there ANY pedagogical issues the AI didn't catch?
