# g6-english-home-language-exam-t4

**AI moderator verdict:** NEEDS_WORK  |  **score:** 3/5  |  **version:** original

## AI recommendation

This paper is FIXABLE with targeted corrections. Strengths include a coherent, age-appropriate stimulus text, well-structured sections, clear question wording, and balanced coverage of reading comprehension, visual text analysis, and language skills. The memo is detailed and provides good marking guidance overall. However, three BLOCKING issues undermine publication readiness: (1) the mark value for Q2 (summary) is contradicted between the question stem and the metadata; (2) Q1.4 is misclassified cognitively (Reorganisation vs. Literal); and (3) Q4.7 is seriously misclassified (Inferential vs. Literal). Correcting these three cognitive-level and mark-allocation errors will align the paper with CAPS cognitive framework requirements and Barrett's Reading Taxonomy, and eliminate teacher confusion at the point of use. The paper's stimulus quality, language register, and cultural sensitivity are strong; a regen pass addressing the three flagged issues should yield a publication-ready exam.

## Dimension scores (1-5)

| Dimension | Score | Notes |
|---|---|---|
| memoAccuracy | 4/5 | Memo answers are factually sound and well-reasoned, with appropriate guidance for marking short-answer and comprehension questions. One minor query on question 2 guidance (see critical issues). |
| cognitiveLevelIntegrity | 3/5 | Multiple mismatches between labelled cognitive levels and actual question demand. Q1.4 labelled Reorganisation but reads as Literal recall; Q4.7 labelled Inferential but tests identification (lower level); others show inconsistencies with Barrett's framework. |
| topicAlignment | 3/5 | Most questions align to their stated topics, but the composite topic labels (e.g. 'Response to Texts exam (50 marks)...') are vague metadata rather than specific topic descriptors, making alignment assessment difficult. |
| markFairness | 3/5 | Mark allocation is partly arbitrary: Q2 marked 2 but asks for FIVE points × 1 mark each, creating confusion; Q1.5 (5 marks) is proportional, but Q1.8 (3 marks) and Q1.9 (2 marks) lack clear mark breakdowns for extended response. |
| mcqQuality | 5/5 | Single MCQ (Q4.4) is well-constructed: one correct answer (b='which'), plausible distractors (who, whom, whose all grammatically distinct), parallel options. |
| questionClarity | 4/5 | Most questions are clearly worded and unambiguous. Q1.5 and Q1.8 are slightly wordy but still clear. No vocabulary register mismatch for Grade 6. |
| stimulusQuality | 5/5 | Passage is coherent, age-appropriate, internally consistent, and well-written. Infographic description is detailed and verbal rendering adequately conveys the visual layout. Both stimuli are engaging. |
| capsCompliance | 3/5 | Cover page is complete and includes examiner field. Sections progress from comprehension → summary → language/visual text (reasonable order). However, cognitive level distribution does not strictly follow CAPS prescription (20% Literal, 20% Reorganisation, 40% Inferential, 20% Evaluation), and section-level cognitive ordering is inconsistent. |
| languageRegister | 5/5 | Grammar and spelling are accurate throughout. Register is appropriate for Grade 6 EHL. Question stems and memo use appropriate academic vocabulary without being inaccessible. |
| biasSensitivity | 5/5 | No gender, racial, ethnic or socioeconomic stereotyping. Names in examples are generic or institutional. SA-relevant context (South Africa levy on plastic bags, WWF/UNEP sources) is present and appropriate. |
| culturalContext | 5/5 | Passage includes SA-specific reference (South Africa plastic bag levy, 2004). Infographic credits WWF/UNEP (international reputable sources). Overall contextually balanced for a South African Grade 6 audience. |
| curriculumCoverage | 4/5 | Paper covers reading comprehension, visual text analysis, summary writing, and language structures (tense, relative clauses, punctuation, voice, reported speech, sentence types, vocabulary). Good spread across reading, writing (summary), and language. No oral component is assessed (noted in topicScope but not required for this exam format). |

## BLOCKING issues (3)

- **Q2 — markFairness**
  - Issue: Question stem says 'Summarise FIVE ways...' with instruction '(5 × 1 mark)', but the memo field shows 'marks: 2'. This creates ambiguity: is the question worth 2 marks or 5 marks? The marking guidance lists six possible points (1 mark each), confirming the intent is 5 marks total, but the metadata contradicts this. A teacher using this paper would be confused about the correct total for Section B.
  - Suggested fix: Change the memo 'marks' field from 2 to 5. Alternatively, clarify in the question stem: 'Summarise FIVE ways... (5 marks)' and ensure the data structure reflects '5' as the total marks.

- **Q1.4 — cognitiveLevelIntegrity**
  - Issue: Question 1.4 is labelled 'Reorganisation' but the stem 'In your own words, explain what microplastics are and how they are formed' is actually a Literal or simple Reorganisation demand—it asks the learner to restate/reorganise information directly available in paragraph 3. The memo answer ('Microplastics are very small plastic particles...formed when larger plastic objects are broken down...') is a near-paraphrase of the passage text. Reorganisation in Barrett's framework typically involves summarising multiple pieces of information or reordering ideas; this question only requires restating one paragraph. Recommend labelling as Literal.
  - Suggested fix: Change Q1.4 cognitive level from 'Reorganisation' to 'Literal'. Or, if intent is Reorganisation, reword the stem to ask learners to synthesise how microplastics form AND their effects (drawing ideas from multiple paragraphs).

- **Q4.7 — cognitiveLevelIntegrity**
  - Issue: Question 4.7 ('Identify the type of sentence below and explain ONE feature...') is labelled 'Inferential' but actually tests identification and explanation of sentence structure—a much lower cognitive demand. Identifying sentence types (complex, simple, compound) is a Literal or basic Reorganisation task (recalling definitions and recognising patterns). The question does not ask learners to infer meaning or interpret effect; it asks them to label and describe. This mislabelling contradicts Barrett's framework.
  - Suggested fix: Change Q4.7 cognitive level from 'Inferential' to 'Literal' (or 'Reorganisation' if explanation is valued). Alternatively, reword to ask: 'Why is the sentence structure effective in conveying the message?' to genuinely require Inferential reasoning.

## Advisory issues (2)

- **Qcover — capsCompliance**: The cognitive framework distribution (20% Literal, 20% Reorganisation, 40% Inferential, 20% Evaluation) is prescribed in the meta section, but the actual question distribution does not match these percentages precisely. Literal questions (1.1, 1.2, 1.3, 3.1, 4.4, 4.8, 4.9) account for ~14 marks out of 50 (~28%); Reorganisation (1.4, 2, 4.1–4.6) account for ~15 marks (~30%); Inferential (1.5, 1.6, 1.9, 3.2, 3.4, 4.7, 4.10) account for ~16 marks (~32%); Evaluation (1.7, 1.8, 3.3) account for ~10 marks (~20%). While reasonably close, this imbalance suggests the framework was not strictly adhered to during design. No BLOCKING action required (tolerance is normal), but should be flagged as a design consideration.
- **Q2 — memoAccuracy**: The marking guidance for Q2 states 'Responses must be in the learner's own words — do not award marks for direct copying.' However, some of the six listed acceptable points are very close to passage wording (e.g. 'More than 60 countries have introduced bans or levies on plastic bags' is almost verbatim from paragraph 4). Guidance should clarify what constitutes 'own words' versus acceptable close paraphrase, to ensure consistent marking across teachers.

---

### What we want from your review

1. Open the DOCX file. Read it as if you received it from a colleague.
2. Would you publish it for your class as-is? With minor edits? Not at all?
3. Look at the AI moderator's verdict above. Does it match your judgement?
   - If the AI said PASS but you would NOT publish: what did it miss?
   - If the AI flagged BLOCKING issues but you would publish anyway: which flags are pedantic?
4. Are there ANY pedagogical issues the AI didn't catch?
