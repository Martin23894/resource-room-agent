# g6-social-sciences-history-exam-t2

**AI moderator verdict:** NEEDS_WORK  |  **score:** 3/5  |  **version:** original

## AI recommendation

This is a well-structured, topic-aligned, and stimulus-rich exam paper that demonstrates solid understanding of Grade 6 Social Sciences curriculum. The cover page is complete, stimuli are engaging and age-appropriate, and most questions are clearly worded. However, there are THREE BLOCKING mark allocation issues (questions 2.3, 3.3, and cumulative fairness across the paper) that create inconsistency between question demand and marks awarded, particularly for multi-part explanation questions. Additionally, one cognitive level labelling issue (3.1 should be Middle Order, not Low Order) and vague extended response marking guidance (6.2, 7.2) need clarification. With targeted corrections to mark allocation, cognitive level relabelling, and extended response rubrics, this paper can reach PASS status. The content, stimulus quality, and curriculum coverage are strong; the issues are mainly structural and marking-related.

## Dimension scores (1-5)

| Dimension | Score | Notes |
|---|---|---|
| memoAccuracy | 3/5 | Most memo answers are factually correct, but significant mark allocation discrepancies exist between question demand and marks awarded. For example, 2.3 asks for two reasons but is marked out of 3 (not 4), and 3.3 asks to describe TWO reasons but is also marked 3. Marking guidance for extended responses (6.2, 7.2) is vague. |
| cognitiveLevelIntegrity | 3/5 | Several mismatches detected. Question 2.3 (asks 'explain why' with two reasons) is tagged Middle Order but the demand is moderate. Questions 3.1 and 3.2 both ask for application/explanation yet 3.1 is Low Order (should be Middle). Question 5.2 asks to explain two reasons using source and own knowledge — this is clearly Middle Order and correctly tagged, but the mark allocation (3) is low for a two-reason explanation. |
| topicAlignment | 4/5 | Topics generally align well with questions. One minor concern: question 4.2 compares San and Khoikhoi but the question stem does not reference a stimulus, making it reliant on learner knowledge. This is acceptable but shifts the test type from source-based to recall-based. |
| markFairness | 2/5 | Significant fairness issues. Question 2.3 requests two reasons with 'TWO reasons' in stem but awards only 3 marks (should be 4: 2 marks per reason). Question 3.3 similarly requests TWO reasons but awards 3 marks. Questions 5.2 and 5.4 both award 3 marks for complex multi-part explanations. Extended response questions (6.1, 6.2, 7.1, 7.2) have inconsistent mark allocations relative to demand. |
| mcqQuality | 4/5 | MCQ options are grammatically parallel and distractors are plausible. All questions have exactly one correct answer. Minor note: option (a) for Q1.4 ('settled farmers') is historically inaccurate (the Bantu were settled farmers, not the San), but it serves as a plausible distractor for Grade 6 learners. |
| questionClarity | 4/5 | Most questions are clear and unambiguous. Question 2.3 stem says 'Give TWO reasons' but the marking scheme refers to 'any two well-explained reasons' — this is acceptable. Question 6.2 is slightly complex ('Argue BOTH sides') but appropriate for Grade 6 extended response. Overall clarity is good. |
| stimulusQuality | 4/5 | Stimuli are relevant, age-appropriate and coherent. Source A (Cradle of Humankind passage) is clear and factually accurate. Source B (Berlin Conference table) is well-structured. Source C (Mapungubwe scenario) is engaging. Word counts and descriptions are appropriate for Grade 6. |
| capsCompliance | 4/5 | Cover page is complete with subject, grade, term, marks, time and learner info fields. Examiner field is present. Sections A–D are ordered from low-to-high cognitive demand (MCQ → Short Answer → Source-based → Extended), which is appropriate. One minor: the cognitive framework breakdown (30% Low, 50% Middle, 20% High) is noted but not perfectly reflected in actual mark distribution. |
| languageRegister | 4/5 | Grammar and spelling throughout are correct. Register is appropriate for Grade 6 (clear, accessible language in stems and stimuli). No obvious errors in phrasing or vocabulary appropriateness. Memo explanations are clear and professional. |
| biasSensitivity | 4/5 | Paper is free from gender, racial and socioeconomic stereotyping. Historical figures mentioned (Robert Broom, Ron Clarke, King Leopold II) are correctly identified. The treatment of indigenous peoples is respectful and academically sound. No cultural insensitivity detected. |
| culturalContext | 5/5 | Excellently contextualized to South Africa. All stimuli are SA-relevant (Cradle of Humankind in Gauteng, Mapungubwe on SA border, Berlin Conference impact on SA colonisation). Place names, historical figures and events are all grounded in SA history. |
| curriculumCoverage | 4/5 | Good spread across the five prescribed topics. Cradle of Humankind (Section A, B), Mapungubwe (A, B, D), Indigenous peoples (A, B), Berlin Conference and Scramble for Africa (A, C), and colonisation impact (D) are all represented. Coverage is balanced and term-aligned. |

---

### What we want from your review

1. Open the DOCX file. Read it as if you received it from a colleague.
2. Would you publish it for your class as-is? With minor edits? Not at all?
3. Look at the AI moderator's verdict above. Does it match your judgement?
   - If the AI said PASS but you would NOT publish: what did it miss?
   - If the AI flagged BLOCKING issues but you would publish anyway: which flags are pedantic?
4. Are there ANY pedagogical issues the AI didn't catch?
