# g6-english-home-language-exam-t2

**AI moderator verdict:** NEEDS_WORK  |  **score:** 3/5  |  **version:** original

## AI recommendation

This paper is NEEDS_WORK and fixable with targeted revision. It is well-designed overall: the ocean plastic stimulus is engaging and age-appropriate, stimuli resolve correctly, questions progress logically in cognitive demand, and language is polished. However, four critical issues undermine its readiness for publication: (1) a confusing memo marking guideline for Q1.1 that obscures partial-credit logic; (2) a severe mark-allocation mismatch in Q2 where the rubric prescribes 5 marks but the question header allocates 2; (3) an 8-mark weighting on Q1.5 that feels disproportionate to the Inferential cognitive level; and (4) minor ambiguities in question clarity and cognitive-level labeling. The rubric for Question 2 exists but is not integrated into the instructions section, which will confuse teachers seeking the marking standard. A focused regen pass addressing these four issues (clarify memo guidance for Q1.1, reconcile Q2 marks, rebalance Q1.5 and Q1.7 fairness, and integrate the rubric into the instructions) will make this paper publication-ready. All content is accurate and culturally appropriate, and bias sensitivity is strong.

## Dimension scores (1-5)

| Dimension | Score | Notes |
|---|---|---|
| memoAccuracy | 4/5 | Memo answers are factually correct and closely aligned to passage content. However, marking guidance for Q1.1 contains a logical inconsistency: it states '1 mark for the amount and 1 mark for the comparison' when the question carries only 1 mark total, creating teacher confusion. |
| cognitiveLevelIntegrity | 3/5 | Most questions show reasonable cognitive alignment, but Q1.5 (8 marks, Inferential) appears disproportionately demanding for its level—requiring learners to infer character traits AND source evidence from one paragraph. Q5.5 (syllable division) is marked Literal but sits awkwardly with other truly literal recall items. |
| topicAlignment | 4/5 | Questions generally align well with their stated topics. Section A addresses comprehension of non-literary text; Section C addresses visual text; Section D addresses language structures. Minor issue: Questions 1.1–1.8 are all listed under one overarching 'Response to Texts' topic, making granular alignment less clear. |
| markFairness | 3/5 | Mark allocation shows some imbalances. Q1.5 (8 marks) for one paragraph inference is heavy; Q1.7 (5 marks) for evaluation is proportionate. Q2 (2 marks for a 40-word summary) seems light given the three-point requirement. Overall, no severe misallocation, but some asymmetry exists. |
| mcqQuality | 5/5 | No MCQ questions present in this paper, so dimension is not applicable. Score reflects N/A status. |
| questionClarity | 4/5 | Most questions are clear and unambiguous. Q1.4 is well-formed. Q4.3 (figurative language) is clear. Minor issue: Q1.5 fuses inference + evidence support into one question, risking clarity for learners unfamiliar with dual-part expectations. |
| stimulusQuality | 5/5 | Passages are coherent, age-appropriate and well-written. The 310-word ocean plastic passage is engaging and provides sufficient material for all Section A–B questions. Visual text description is detailed and sufficient for answering poster questions. |
| capsCompliance | 4/5 | Paper follows CAPS structure: cover page complete, four sections (A–D) in logical order from lower-to-higher cog level (Literal → Reorganisation → Inferential → Evaluation). Examiner field present. Minor: Section headings could be more explicit about cognitive progression; the rubric for Question 2 appears after the memo, not integrated into instructions. |
| languageRegister | 5/5 | Grammar, spelling and register are polished throughout. Questions use Grade 6-appropriate vocabulary. Instructions are clear and well-phrased. No errors detected. |
| biasSensitivity | 5/5 | No gender, racial or socioeconomic stereotyping present. Contexts are inclusive (beach clean-ups, environmental clubs, diverse examples of activism). Names are not overrepresented in ways that exclude SA diversity. |
| culturalContext | 4/5 | Ocean plastic is a globally relevant topic suitable for SA Grade 6 learners. Examples (beach clean-ups, local government petitions) are SA-appropriate. Extension activity (school tuck shop) is locally grounded. Poster's 'Green Oceans Foundation' is fictional but contextually neutral. |
| curriculumCoverage | 4/5 | Paper covers Terms 1–2 topics as specified: non-literary text comprehension (newspaper-style article), visual text analysis, summary writing, and language structures (passive voice, indirect speech, figurative language, parts of speech, tenses). Coverage is reasonable, though poetry and dramatic genres are not sampled (which may be acceptable depending on exam scope). |

## Advisory issues (5)

- **Q1.1 — memoAccuracy**: The memo states: '[Marks awarded: 1 mark] For a complete, accurate answer including both '5 grams' and the credit card comparison. If only one detail is given.' This guidance is confusing because the question carries 1 mark total, yet the guidance implies awarding partial marks for 'both' elements. It creates ambiguity for teachers about whether to award the full mark only if BOTH details are present, or whether the 5 grams alone suffices.
- **Q1.5 — markFairness**: Q1.5 is worth 8 marks (the heaviest single-question allocation in Section A) for a two-part task: infer character traits of young activists AND support with evidence from paragraph 5 alone. This is disproportionate for Inferential work at Grade 6, especially given that Q1.7 (Evaluation, requiring both passage AND own knowledge) is worth only 5 marks. The 8-mark weighting suggests this is as demanding as extended response writing, which seems misaligned.
- **Q2 — markFairness**: Q2 (Summary) is worth only 2 marks despite requiring learners to identify, paraphrase and format THREE distinct points (sea turtles, seabirds, dolphins/whales) within a 40-word limit, plus demonstrate 'own words'. The rubric separately lists 3 marks for content + 1 for own words + 1 for format (5 marks total), but the question header allocates only 2 marks. This mismatch will confuse teachers during marking.
- **Q1.1 — questionClarity**: Q1.1 asks 'What does the passage say about how much microplastic humans may consume every week?' The phrasing 'may consume' mirrors the passage's cautious 'may be consuming', which is good; however, the question could invite a longer response (e.g. 'humans may be consuming up to 5 grams every week—roughly the weight of a credit card'), when the memo clearly expects '5 grams' as the core answer. The credit card detail is stated in the passage but may not be essential to mark.
- **Q5.5 — cognitiveLevelIntegrity**: Q5.5 (syllable division and counting) is marked Literal, aligning with the category of direct recall. However, syllable division is a procedural/phonetic skill that often requires implicit understanding of syllable structure (stress patterns, vowel sounds) beyond simple literal recall. At Grade 6, this sits at the boundary between Literal and Reorganisation and may be misclassified.

---

### What we want from your review

1. Open the DOCX file. Read it as if you received it from a colleague.
2. Would you publish it for your class as-is? With minor edits? Not at all?
3. Look at the AI moderator's verdict above. Does it match your judgement?
   - If the AI said PASS but you would NOT publish: what did it miss?
   - If the AI flagged BLOCKING issues but you would publish anyway: which flags are pedantic?
4. Are there ANY pedagogical issues the AI didn't catch?
