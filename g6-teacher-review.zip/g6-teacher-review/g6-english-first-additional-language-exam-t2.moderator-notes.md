# g6-english-first-additional-language-exam-t2

**AI moderator verdict:** NEEDS_WORK  |  **score:** 3/5  |  **version:** original

## AI recommendation

This paper has solid structural foundations and age-appropriate content, but contains several blocking issues that must be resolved before publication. The primary concern is a mismatch between the stated cognitive level distribution (20% Literal, 20% Reorganisation, 40% Inferential, 20% Evaluation) and the actual distribution of questions across the paper, particularly an over-weighting of Inferential questions (1.3, 1.4, 1.6, 3.2, 3.4, 5.3, 5.4, 6.3 = 8 questions marked Inferential against only 6 total Literal questions). Additionally, Question 2.1 contains a blocking mark allocation issue: the summary task asks for FIVE points but is allocated only 2 marks, creating severe fairness problems. The rubric provided suggests 5 marks are possible, creating internal inconsistency. Three language-register advisories flag awkwardness in question stems (6.1 punctuation task wording, 4.2 pronoun selection, 5.1 indirect speech acceptance note). With targeted fixes to the cognitive level tagging and mark allocation for Question 2.1, this paper is salvageable.

## Dimension scores (1-5)

| Dimension | Score | Notes |
|---|---|---|
| memoAccuracy | 5/5 | All memo answers are factually accurate, well-reasoned, and properly supported. Arithmetic is sound where applicable. Marking guidance is clear and actionable; partial-credit rules and acceptable variants are explicitly stated. |
| cognitiveLevelIntegrity | 2/5 | Significant mismatches identified. Eight questions are labelled Inferential (1.3, 1.4, 1.6, 3.2, 3.4, 5.3, 5.4, 6.3), but the cognitive framework prescribes only 40% (20 marks) for this level. Actual question distribution far exceeds this target. Additionally, Q1.5 is labelled Reorganisation but the demand ('Explain in your own words') leans more Inferential. Cognitive level tagging requires systematic correction. |
| topicAlignment | 5/5 | All questions are clearly aligned to their stated topics. Reading/viewing questions address comprehension of texts; language questions test specific grammatical structures; summary tests synthesis from passage. No topic drift detected. |
| markFairness | 2/5 | Question 2.1 is severely under-marked. The stem asks for FIVE points in point form, but allocates only 2 marks. The rubric provides a 5-mark maximum, creating internal inconsistency and unfair mark allocation relative to learner effort. Additionally, the total 50 marks across the paper does not align neatly with the cognitive distribution (10+10+20+10=50, but actual questions do not achieve this distribution by cog level). |
| mcqQuality | 5/5 | No MCQ items in this paper. This dimension is not applicable. |
| questionClarity | 4/5 | Most questions are clear and unambiguous. Minor advisory issues: Q6.1 uses confusing phrasing ('add the correct punctuation' — specify what errors to look for); Q4.2 could be clearer that only one answer per blank is expected; Q5.1 acceptance note ('The teacher said that we must protect our oceans') is confusing as written. |
| stimulusQuality | 5/5 | Both stimuli are well-constructed. The 'OUR OCEANS ARE IN DANGER' passage is coherent, age-appropriate, 220 words as declared, and factually sound. The visual text description is detailed and allows learners to answer questions without seeing the actual image. All stimulus references resolve correctly. |
| capsCompliance | 4/5 | Cover page is complete with all required fields. Sections are ordered low-to-high cognitive demand (A comprehension literal/reorganisation first, then summary, then visual text with mixed cog levels, then language). However, the actual distribution within sections does not match the prescribed Barrett's framework percentages, which is a structural compliance issue. |
| languageRegister | 4/5 | Grammar and spelling are consistently correct. Register is appropriate for Grade 6 FAL learners. Minor advisory: Q6.1 phrasing 'Rewrite the following passage and add the correct punctuation. (There are FOUR punctuation errors.)' is awkward — should say 'Add four pieces of punctuation' or 'Correct four punctuation errors.' Q5.1 memo note is awkwardly phrased. |
| biasSensitivity | 5/5 | No gender, racial, or socioeconomic stereotyping detected. Stimulus content is inclusive and places no discriminatory assumptions on learners. Environmental context is universally relevant. |
| culturalContext | 5/5 | Content is appropriately framed within an SA environmental context. Ocean pollution, beach clean-ups, and recycling are relevant to all SA learners. No Western-centric assumptions; references (rivers, oceans, beaches) are geography-appropriate. |
| curriculumCoverage | 4/5 | Paper covers a reasonable spread of Term 2 topics: reading non-literary text, summary, visual text, and language (nouns, pronouns, speech, voice, figurative language, punctuation, tenses). Term 1 topics are less visibly represented, though the topicScope lists both terms as covered. |

## BLOCKING issues (2)

- **Q2.1 — markFairness**
  - Issue: The stem explicitly asks: 'Summarise the ways in which plastic pollution harms marine animals. List FIVE points in your own words.' However, only 2 marks are allocated. The accompanying rubric shows a 5-mark scale, creating internal contradiction. A summary of five distinct points should require proportionally more effort than 2 marks reflects. This is fundamentally unfair to learners and undermines teacher trust.
  - Suggested fix: Either (a) increase the mark allocation for 2.1 to 5 marks and update the cognitive framework mark distribution accordingly, or (b) reduce the demand to 'List THREE points' and retain 2 marks. Option (a) is recommended as it aligns with the provided rubric and the complexity of the task.

- **Qcover — cognitiveLevelIntegrity**
  - Issue: The paper claims to follow Barrett's cognitive distribution: 20% Literal (10 marks), 20% Reorganisation (10 marks), 40% Inferential (20 marks), 20% Evaluation and Appreciation (10 marks). However, actual question tagging shows: Literal: 1.1, 1.2, 3.1, 4.1, 6.2 (5 questions, ~11 marks); Reorganisation: 1.5, 4.2, 5.1, 5.2, 6.1 (5 questions, ~10 marks); Inferential: 1.3, 1.4, 1.6, 3.2, 3.4, 5.3, 5.4, 6.3 (8 questions, ~19 marks); Evaluation: 1.7, 1.8, 3.3 (3 questions, ~8 marks). Inferential is significantly over-represented and Evaluation under-represented. This violates CAPS structural integrity.
  - Suggested fix: Re-tag questions to achieve the prescribed distribution. Specifically: downgrade 1.3, 1.4, 1.6 from Inferential to Reorganisation or move some to Evaluation. Upgrade 3.3 and 1.8 to stronger Evaluation tasks. Ensure the final distribution aligns with 20-20-40-20 split by reviewing each stem's actual cognitive demand.

## Advisory issues (4)

- **Q1.5 — cognitiveLevelIntegrity**: Question 1.5 is tagged 'Reorganisation' but the stem ('Explain in your own words what is meant by…') actually calls for Inferential comprehension—the learner must deduce the logical contradiction between 'full stomachs' and 'dying of hunger' using conceptual reasoning beyond direct text reorganisation. The 1-mark allocation also seems light for an inferential task.
- **Q6.1 — questionClarity**: The stem reads: 'Rewrite the following passage and add the correct punctuation. (There are FOUR punctuation errors.)' The phrasing is ambiguous — it is unclear whether learners should identify and correct four existing errors or add four pieces of punctuation to an un-punctuated passage. The memo clarifies the task, but the stem itself should be self-contained and unambiguous.
- **Q4.2 — questionClarity**: The stem provides five options in a box [she / this / they / those / it] for four blanks. It is not explicitly stated whether each pronoun can be used only once or whether repeats are allowed. While contextually the answers are unique, the instruction should be clearer.
- **Q5.1 — questionClarity**: The memo's acceptance note states: 'Also accept: "The teacher said that we must protect our oceans from plastic pollution" if the reporting context justifies it.' This alternative answer changes the grammatical transformation (it keeps 'we' and 'our' instead of shifting to 'they' and 'their'), which contradicts the standard rule for indirect speech when the speaker is someone else. The note introduces ambiguity about what is acceptable.

---

### What we want from your review

1. Open the DOCX file. Read it as if you received it from a colleague.
2. Would you publish it for your class as-is? With minor edits? Not at all?
3. Look at the AI moderator's verdict above. Does it match your judgement?
   - If the AI said PASS but you would NOT publish: what did it miss?
   - If the AI flagged BLOCKING issues but you would publish anyway: which flags are pedantic?
4. Are there ANY pedagogical issues the AI didn't catch?
