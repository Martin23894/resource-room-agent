# g6-english-home-language-test-t3

**AI moderator verdict:** NEEDS_WORK  |  **score:** 3/5  |  **version:** original

## AI recommendation

This Grade 6 English Home Language test has strong stimulus materials, clear instructions, and age-appropriate reading and language tasks. However, it has four critical structural issues that prevent publication. (1) The memo answers for Q1.3 and Q1.4 contain contradictory mark guidance that teachers cannot apply. (2) The cognitive level labelling is mismatched: Q3.4 (synthesis) is tagged Inferential; Q2.4 (comparison/inference) is tagged Reorganisation. (3) Most critically, Section C (Writing) is allocated only 3 marks despite the meta and topic scope claiming the creative writing task is worth 40 marks—this is a broken schema. (4) The Writing Rubric is poorly structured and does not align clearly with the 3-mark allocation. The paper requires targeted regeneration of: the memo answers (Q1.3, Q1.4, Q5.1); cognitive level relabelling (Q2.4, Q3.4); substantial rebalancing of Section C marks (recommend 12–15 marks for the creative writing task); and a revised, clearer Writing Rubric. Recommend NEEDS_WORK with mandatory fixes to memo accuracy, cognitive integrity, and mark allocation before publication.

## Dimension scores (1-5)

| Dimension | Score | Notes |
|---|---|---|
| memoAccuracy | 3/5 | Multiple memo answers contain guidance inconsistencies and insufficient clarity. Q1.3 marks allocation (1 mark) contradicts the guidance which lists three separate criteria. Q1.4 memo guidance is contradictory. Q5.1 rubric is fragmented and lacks clear mark distribution across three criteria. |
| cognitiveLevelIntegrity | 2/5 | Significant mismatches between labelled cognitive level and actual question demand. Q3.4 is labelled Inferential but requires synthesis/creation typical of Problem Solving. Q2.4 (marked Reorganisation) demands comparison/inference. Q1.6 is appropriately Inferential but the prompt is ambiguous about the depth expected. |
| topicAlignment | 4/5 | Questions generally align with stated topics. However, the Writing section (Q5.1, marked 3 marks) is labelled 'Writing: creative writing project (40 marks)' but only 3 marks are allocated, creating confusion. |
| markFairness | 2/5 | Severe mark allocation issues. Section A = 18 marks; Section B = 8 marks; Section C = 3 marks. A creative writing task typically demands higher allocation than 3 marks; the contrast is unbalanced. Q1.4 (4 marks) for a three-part explanation is reasonable, but Q5.1 (3 marks for a 15–20 line scene with dialogue and conventions) is under-weighted. |
| mcqQuality | 5/5 | Q1.5 is well-constructed: one clear correct answer (b), three plausible and grammatically parallel distractors all drawn from the passage content. No issues detected. |
| questionClarity | 4/5 | Most questions are clear. Q1.6 stem is slightly ambiguous ('reasoned response' is vague). Q5.1 specifies 'approximately 15–20 lines' but the rubric does not reference length as a criterion, creating potential grading confusion. |
| stimulusQuality | 4/5 | Both passages are coherent, age-appropriate, and internally consistent. Word counts are stated. Minor: the drama extract is relatively short (140 words) but sufficient for Grade 6 reading-level drama analysis. |
| capsCompliance | 4/5 | Cover page is complete with required fields (name, surname, date, examiner, time, total). Sections progress from Reading (lower cog) to Language to Writing, broadly correct. However, the Writing section contains only one extended response (Q5.1) with extremely low mark allocation (3 marks) given the topic scope states 'creative writing project (40 marks)'—this is a mismatch between meta and actual question design. |
| languageRegister | 5/5 | Grammar and spelling are correct throughout. Register is appropriate for Grade 6. Instructions are clear and concise. No language errors detected. |
| biasSensitivity | 5/5 | No gender, racial, or socioeconomic stereotyping. Character names (Maya, Dan, Officer Nkosi) reflect South African diversity. No cultural bias in stimuli or questions. |
| culturalContext | 4/5 | Stimuli are appropriately South African (references to South African beaches, loggerhead turtles, Officer Nkosi). Set in a local context. Minor: the drama extract's opening could have specified a named SA beach (e.g. uMhlanga, Cape Vidal) for stronger local relevance. |
| curriculumCoverage | 3/5 | Paper covers stated topics (Reading/Viewing non-literary and drama; Language on complex sentences and punctuation). However, only one type of writing task is offered in Section C, and the term's 'creative writing project' is compressed into a single 3-mark scene. Limited breadth in Writing assessment. |

## BLOCKING issues (5)

- **Qmemo:1.3 — memoAccuracy**
  - Issue: Memo answer for Q1.3 allocates 1 mark but the guidance describes three separate marking criteria: instinct toward bright light (1), artificial lights brighter than ocean (1), hatchlings go toward roads/die (1). This totals 3 marks' worth of criteria, but only 1 mark is available. The guidance is contradictory and unusable by a teacher.
  - Suggested fix: Revise the memo to either: (a) increase the mark allocation to 3 marks and restructure the guidance, OR (b) reduce the marking guidance to one clear criterion (e.g., 'Award 1 mark for explaining that artificial lights confuse hatchlings by appearing brighter than the ocean'). Recommend option (a) to match the complexity of the answer.

- **Qmemo:1.4 — memoAccuracy**
  - Issue: Q1.4 memo guidance states: 'Must include both the cause (plastic mistaken for jellyfish) and the effect (blockage/starvation). Textual reference required for third mark.' This implies marks are awarded for: cause (1), effect (1), textual reference (1) = 3 marks. However, the question is worth 4 marks. The guidance does not clarify where the fourth mark is awarded or what additional component is needed.
  - Suggested fix: Revise the memo guidance to explicitly allocate all 4 marks, e.g.: 'Award 1 mark for identifying that turtles mistake plastic for jellyfish; 1 mark for explaining the digestive blockage; 1 mark for stating the consequence (starvation/death); 1 mark for inclusion of a direct textual reference (e.g., "more than half...").' Ensure guidance is complete and clear.

- **Q3.4 — cognitiveLevelIntegrity**
  - Issue: Q3.4 is labelled Inferential but the stem asks learners to 'Rewrite the following simple sentence as a COMPLEX sentence by adding a suitable subordinate clause.' This is a synthesis/creation task that requires learners to generate new content (not merely infer from given text). This demand is characteristic of Problem Solving or higher-order creative work in Barrett's framework, not Inferential (which involves drawing conclusions from existing text).
  - Suggested fix: Reclassify Q3.4 as Evaluation and Appreciation, as it requires learners to create and defend a new construction. Alternatively, revise the question to ask learners to infer a missing cause/effect relationship first, then construct the sentence based on that inference.

- **Q5.1 — markFairness**
  - Issue: Q5.1 is worth only 3 marks despite being a creative writing task requiring 15–20 lines of dialogue, stage directions, character development, and a meaningful ending. Section A (Reading) is worth 18 marks; Section C (Writing) is worth 3 marks. This is grossly disproportionate. For a Grade 6 English Home Language test, a creative writing task of this scope should command 15–20 marks minimum, not 3. The cover sheet and meta state the total is 40 marks, but Section C contributes only 7.5% of the assessment weight, which is inappropriate for a writing-heavy curriculum.
  - Suggested fix: Revise Section C to allocate 12–15 marks to Q5.1 (increase the rubric to include detailed criteria: content/relevance, dramatic conventions, language accuracy, creativity, and length/completion). Adjust total marks to 50 or rebalance other sections accordingly.

- **Qcover — capsCompliance**
  - Issue: The meta field states 'totalMarks: 40' and the topic scope states 'Writing: creative writing project (40 marks)'. This is contradictory: the Writing section (Q5.1) is allocated only 3 marks, not 40. Either the meta totalMarks should be 29 (18 + 8 + 3) or Section C should allocate 40 marks to the creative writing project. The paper as currently structured has a broken mark schema.
  - Suggested fix: Clarify and reconcile the meta totalMarks and topicScope. Recommend: set totalMarks = 29 (Reading 18 + Language 8 + Writing 3) and revise topicScope to state 'Writing: creative writing task (3 marks)' OR increase Section C to 40 marks and adjust totalMarks to ~70. Recommend the latter to align with CAPS emphasis on extended writing.

## Advisory issues (4)

- **Q2.4 — cognitiveLevelIntegrity**: Q2.4 is labelled Reorganisation ('Compare the attitudes of Maya and Dan…') but the task actually demands Inferential thinking. The extract does not explicitly state the attitudes side by side; learners must infer Dan's caution from his nervous tone and Maya's determination from her dialogue, then synthesize a comparison. Reorganisation implies reordering/summarising stated information; this task goes beyond that.
- **Qmemo:5.1 — memoAccuracy**: The memo for Q5.1 states 'Marks awarded: Content and relevance = 1; Language and structure = 1; Creativity and engagement = 1' but the rubric below does not clearly indicate how marks are distributed within each criterion. The rubric descriptors (e.g., 'Excellent = 1 mark', 'Adequate = 1 mark', 'Developing = 0 marks') are ambiguous: does a learner get 1 mark for Excellent AND 1 mark for Adequate? Or is it a choice? The rubric structure is unclear and unusable.
- **Q1.6 — questionClarity**: Q1.6 stem asks for 'your own reasoned response' but does not specify the expected length or depth. The memo guidance mentions '1 mark for a reasoned personal response,' suggesting learners must provide reasoning, but the phrasing 'reasoned response' is vague. Learners may not be clear on whether a one-sentence response or a paragraph is expected.
- **Q5.1 — questionClarity**: Q5.1 specifies 'Approximately 15–20 lines of dialogue' but the rubric does not include length or completion as a criterion. If a learner writes only 10 lines of high-quality dialogue, should they lose marks? The rubric does not address this, creating ambiguity for marking.

---

### What we want from your review

1. Open the DOCX file. Read it as if you received it from a colleague.
2. Would you publish it for your class as-is? With minor edits? Not at all?
3. Look at the AI moderator's verdict above. Does it match your judgement?
   - If the AI said PASS but you would NOT publish: what did it miss?
   - If the AI flagged BLOCKING issues but you would publish anyway: which flags are pedantic?
4. Are there ANY pedagogical issues the AI didn't catch?
