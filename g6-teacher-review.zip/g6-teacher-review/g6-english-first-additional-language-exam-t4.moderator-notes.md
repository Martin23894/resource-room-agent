# g6-english-first-additional-language-exam-t4

**AI moderator verdict:** NEEDS_WORK  |  **score:** 3/5  |  **version:** original

## AI recommendation

This Grade 6 English FAL exam paper is well-structured, age-appropriate, and covers the curriculum spread adequately. The passage is engaging, the visual stimulus is described clearly, and most questions are unambiguous. However, three BLOCKING issues must be resolved before publication: (1) Q1.3 is tagged as 'Reorganisation' but demands metaphorical inference (Inferential); (2) Q1.3 marked out of 1 in the question but memo claims 2 marks available; (3) Q2 marked out of 2 in the question but memo guidance refers to a 5-mark rubric. Additionally, Q1.5 (8 marks) is disproportionately weighted compared to other Inferential questions, warranting review. Once these inconsistencies are resolved through targeted regen or editing, the paper will be publication-ready. The linguistic and cultural sensitivity are strong, and bias is absent."

## Dimension scores (1-5)

| Dimension | Score | Notes |
|---|---|---|
| memoAccuracy | 3/5 | Most memo answers are factually sound and grounded in the passage, but question 1.3 is internally inconsistent—the memo suggests awarding 2 marks but the question is marked out of 1. The marking guidance for question 2 is confusing and contradicts the stated mark allocation (marked out of 2, not 5). |
| cognitiveLevelIntegrity | 3/5 | Most questions are correctly tagged, but several mismatches exist: Q1.3 is tagged 'Reorganisation' but demands inference of metaphorical meaning (Inferential); Q3.4 is tagged 'Reorganisation' but is purely Literal recall; Q1.1 is multi-point Literal at 2 marks (appropriate). Approximately 2–3 significant mismatches. |
| topicAlignment | 4/5 | All questions align well with their stated topics. The broad 'Year-end exam' topic label is generic but not inaccurate for an exam paper. |
| markFairness | 3/5 | Overall mark allocation is reasonable, but Q1.5 (8 marks for 'explain the relationship') is disproportionately heavy compared to similar Inferential questions (e.g., Q1.4 = 2 marks). Q2 marked out of 2 but memo guidance references 5 marks. |
| mcqQuality | 5/5 | No MCQ questions in this paper; dimension not applicable. Score awarded for structural completeness. |
| questionClarity | 4/5 | Most questions are clear and unambiguous. Q1.3 ('Explain what is meant by the phrase') could be slightly clearer—it briefly signals metaphor but learners may struggle with the expectation. Q3.2 is clear and well-phrased. |
| stimulusQuality | 4/5 | The passage is coherent, age-appropriate, and well-structured at 280 words. The infographic description is vivid and references resolve. Minor: the infographic is described but not shown as a visual; the verbal description is sufficient for all questions to be answerable. |
| capsCompliance | 4/5 | Cover page is complete with subject, grade, term, marks, duration, and learner info fields including Examiner. Instructions are clear. Sections progress logically (Reading → Summary → Language/Visual). Minor: the extension activity is labelled 'not marked' but is included in the paper structure (advisory only). |
| languageRegister | 5/5 | Grammar and spelling are correct throughout. Register is appropriately formal for Grade 6 FAL exam; vocabulary is accessible and consistent. Question stems are well-written. |
| biasSensitivity | 5/5 | No gender, racial, socioeconomic, or cultural stereotyping detected. The passage and questions include diverse geographical references (Nile, Yangtze, Amazon) and focus on environmental equity (safe drinking water access). Names and contexts are inclusive. |
| culturalContext | 4/5 | The infographic is from a fictional SA organisation (WaterWise SA) and uses local context. The passage includes African rivers (Nile) and global examples. Contexts are mostly SA-relevant without being forced; curriculum-appropriate. |
| curriculumCoverage | 4/5 | The paper covers a reasonable spread of Topics 3 and 4: non-literary text (passage), visual text (infographic), summary, language structures (relative clauses, punctuation, tense, word choice). Coverage is balanced across reading, writing (summary), language, and visual literacy. |

## BLOCKING issues (3)

- **Q1.3 — memoAccuracy**
  - Issue: The question is marked out of 1 mark, but the marking guidance states: 'Award a second mark for an explanation or elaboration.' This creates confusion—the memo claims 2 marks are available when the paper allocates only 1 mark.
  - Suggested fix: Align the marking guidance with the 1-mark allocation: 'Award 1 mark for the idea that rivers are essential/vital to life. Do not award additional marks.' Alternatively, if the question should be worth 2 marks, restate the question's mark allocation as 2 and adjust the section marks proportionally.

- **Q1.3 — cognitiveLevelIntegrity**
  - Issue: Q1.3 is tagged as 'Reorganisation' but the stem requires learners to infer the meaning of a metaphor ('rivers are the lifeblood of our planet'). Understanding a metaphor demands Inferential thinking, not simple reorganisation of given information.
  - Suggested fix: Recategorise Q1.3 as 'Inferential' in the question metadata. Adjust section cognitive distribution if necessary to maintain curriculum balance.

- **Q2 — memoAccuracy**
  - Issue: The memo answer for Q2 (Summary) is marked out of 2 marks in the question metadata, but the marking guidance references a 5-mark rubric ('Mark out of 5: each for any FOUR of the following points...'). This is a fundamental inconsistency that will confuse teachers marking the paper.
  - Suggested fix: Standardise the mark allocation. Either: (a) Change the question mark allocation to 5 marks and rewrite the brief marking guidance to align, OR (b) Keep the question at 2 marks and rewrite the rubric guidance to award marks in smaller increments (e.g. 1 mark for 2–3 points, 2 marks for 4 points + language). Also remove or revise the separate rubric section at the end of the memo if it contradicts the inline guidance.

## Advisory issues (3)

- **Q3.4 — cognitiveLevelIntegrity**: Q3.4 is tagged as 'Reorganisation' (implying reordering/summarising from stimulus text), but the infographic provides no definition or explanation of 'grey water.' The question demands learners infer or recall external knowledge (Literal/Prior Knowledge), not reorganisation of stimulus content.
- **Q1.5 — markFairness**: Q1.5 is allocated 8 marks, making it the single heaviest-weighted question on the paper. While it is Inferential and requires evidence-based explanation, similar Inferential questions (Q1.4 = 2 marks, Q1.6 = 3 marks) carry far fewer marks. The disparity is not clearly justified by significantly higher cognitive demand.
- **Q1.2 — memoAccuracy**: The memo guidance for Q1.2 states 'For the full correct sentence; if partially correct (two of three actions mentioned).' This notation is incomplete and unclear. Does 'partially correct' earn 1 mark or full 2 marks?

---

### What we want from your review

1. Open the DOCX file. Read it as if you received it from a colleague.
2. Would you publish it for your class as-is? With minor edits? Not at all?
3. Look at the AI moderator's verdict above. Does it match your judgement?
   - If the AI said PASS but you would NOT publish: what did it miss?
   - If the AI flagged BLOCKING issues but you would publish anyway: which flags are pedantic?
4. Are there ANY pedagogical issues the AI didn't catch?
