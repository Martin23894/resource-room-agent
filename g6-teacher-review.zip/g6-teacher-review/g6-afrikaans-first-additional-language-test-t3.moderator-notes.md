# g6-afrikaans-first-additional-language-test-t3

**AI moderator verdict:** NEEDS_WORK  |  **score:** 3/5  |  **version:** original

## AI recommendation

The paper requires targeted remediation on cognitive-level labelling before publication. Four questions (5.2, 8.1, 8.2, 8.3) are labelled with incorrect cognitive levels, which will mislead teachers and undermine the validity of learner assessment records. The memo is accurate, stimulus materials are sound, and question clarity is generally good. The primary blocker is the cognitive-level mislabelling in Section D (Oral Presentation Planning), where three consecutive questions are incorrectly classified as Inferential when they test Evaluation and Appreciation. Additionally, there is a disconnect between the declared topic scope (60 marks: 40 for creative writing + 20 for oral) and the paper total (40 marks), suggesting either the metadata is aspirational or the paper itself is incomplete. Once these cognitive levels are corrected and the scope clarified, the paper will be publication-ready. No memo errors or bias issues detected.

## Dimension scores (1-5)

| Dimension | Score | Notes |
|---|---|---|
| memoAccuracy | 4/5 | Memo answers are factually correct and aligned to the folk tale and poster; no arithmetic errors. Marking guidance is clear and actionable for most items, though some answers (e.g., 7.1, 7.2) are exemplars rather than exhaustive mark-breakdown. |
| cognitiveLevelIntegrity | 2/5 | Multiple cognitive-level mismatches detected. Question 5.2 (punctuation exercise) is labelled 'Inferential' but is clearly 'Reorganisation' (mechanical skill). Questions 8.1–8.3 are labelled 'Inferential' but test opinion/planning (Evaluation and Appreciation). This pattern confuses the reporting of what students actually know. |
| topicAlignment | 4/5 | Questions align well to their declared topics. Section A tests folk tale comprehension; Section B tests visual literacy (poster). Section C covers compound sentences, relative clauses, and punctuation as labelled. Section D writing tasks map to the creative and oral topics stated. |
| markFairness | 3/5 | Marks are generally proportional (1 mark for literal recall, 2 for explanation, 3 for extended writing). However, Question 7.1 (rewrite ending, 3–4 sentences) is marked 2 marks, while 7.2 (5–6 sentences with rubric) is marked 3 marks; the demand difference feels marginal relative to the mark gap. Question 8 (oral planning) awards 3+2+2=7 marks for planning a presentation that is not actually delivered—this creates tension with the scheme's inclusion of 'Mondeling: mondelinge aanbieding van projek (20 punte)' as a listed topic, yet only 7 marks are allocated here. |
| mcqQuality | 5/5 | No MCQ items in this paper; this dimension is not applicable. |
| questionClarity | 4/5 | Most questions are clear and unambiguous. Question 1.4 stem ('Explain in your own words how…') is slightly ambiguous as to whether a bullet-point summary or full narrative is expected; the answer space (3 lines) suggests narrative. Questions 7.1 and 7.2 specify Afrikaans as the medium, which is appropriate. Minor ambiguity in 8.1–8.3 on depth of response expected, but clarified by answer-space lines. |
| stimulusQuality | 4/5 | The folk tale (190 words) is age-appropriate, coherent, and well-constructed. The poster description is detailed and provides all necessary information for answering Q2. Both stimuli resolve and are sufficient to answer all items. No unresolved references. |
| capsCompliance | 3/5 | Cover page is present with required learner info fields (name, surname, date, examiner, time, total), instructions, and resource label. Sections are ordered A (comprehension, lower cog), B (visual literacy, still lower), C (language structures, mixed), D (writing, higher). However, the cognitive ordering within Section C and D is not entirely clear, and the paper claims 40 marks total but topic scope lists 'kreatiewe skryfprojek (40 punte)' and 'mondelinge aanbieding (20 punte)' which suggests a larger scope than tested here. |
| languageRegister | 4/5 | English stem language is appropriate for Grade 6 and clear. Afrikaans in the folk tale, poster, and answer exemplars is grammatically correct and idiomatic. No obvious translation artifacts or register mismatches. Note: limited confidence in assessing Afrikaans nuance, so this remains advisory. |
| biasSensitivity | 5/5 | Paper contains diverse names and contexts (hasie, leeu, olifant; both boys and girls referenced in questions). The drama festival is SA-based (Paarl venue, R30 pricing). No stereotyping of gender, race, or socioeconomic class detected. |
| culturalContext | 5/5 | Paper is set in SA contexts: Paarl as a venue, R30 pricing (South African Rand). The folk tale is a universal narrative but retold in Afrikaans for Grade 6 FAL. Cultural references are appropriate and inclusive. |
| curriculumCoverage | 4/5 | Paper covers the declared Term 3 topics: folk tale reading (volksverhaal), visual literacy (drama poster), language structures (compound sentences, relative clauses, punctuation), and creative writing. However, the weighting is uneven—writing is only 5 marks of the 40-mark total, despite being a major curriculum outcome, while comprehension and language structure dominate. The oral presentation topic is tested only as planning (7 marks), not actual performance. |

## BLOCKING issues (4)

- **Q5.2 — cognitiveLevelIntegrity**
  - Issue: Question 5.2 ('Rewrite the sentence with correct punctuation') is labelled 'Inferential' but tests Reorganisation-level skill. Punctuation correction is a mechanical, rule-based task requiring learners to apply known conventions—not to infer meaning beyond the text. This mislabelling creates an inaccurate record of learner cognitive demand.
  - Suggested fix: Change cognitive level for Q5.2 from 'Inferential' to 'Reorganisation'.

- **Q8.1 — cognitiveLevelIntegrity**
  - Issue: Question 8.1 ('List THREE things you would do to prepare for your oral presentation') is labelled 'Inferential' but asks learners to plan/suggest strategies. This is Evaluation and Appreciation (generating own ideas and justifying choices), not Inferential (inferring from a given text).
  - Suggested fix: Change cognitive level for Q8.1 from 'Inferential' to 'Evaluation and Appreciation'.

- **Q8.2 — cognitiveLevelIntegrity**
  - Issue: Question 8.2 ('Why is it important to speak clearly…? Give TWO reasons.') is labelled 'Inferential' but asks learners to justify and evaluate the value of communication strategies. This is Evaluation and Appreciation (judging importance), not Inferential (deriving meaning from stimulus text).
  - Suggested fix: Change cognitive level for Q8.2 from 'Inferential' to 'Evaluation and Appreciation'.

- **Q8.3 — cognitiveLevelIntegrity**
  - Issue: Question 8.3 ('Suggest TWO strategies they could use to feel more confident') is labelled 'Inferential' but requires learners to generate and suggest strategies. This is Evaluation and Appreciation (creative problem-solving), not Inferential (inferring from text).
  - Suggested fix: Change cognitive level for Q8.3 from 'Inferential' to 'Evaluation and Appreciation'.

## Advisory issues (3)

- **Q7.1 — markFairness**: Question 7.1 ('Write a different ending, 3–4 sentences in Afrikaans') is allocated 2 marks, while Q7.2 ('Write a short paragraph, 5–6 sentences in Afrikaans') is allocated 3 marks. The length and demand are relatively similar; the 1-mark gap feels small relative to the complexity of both tasks. Learners might reasonably expect 3 marks for a creative rewrite.
- **Qcover — capsCompliance**: The meta declares topic scope to include 'kreatiewe skryfprojek (40 punte)' and 'mondelinge aanbieding van projek (20 punte)', suggesting 60 marks total. However, the paper total is 40 marks. The paper allocates only 5 marks to writing (Q7.1 + Q7.2) and 7 marks to oral planning (Q8.1–8.3), far short of the 40+20 declared. This suggests either the meta is overstated or the paper is incomplete.
- **Q1.4 — questionClarity**: Question 1.4 ('Explain in your own words how the hare tricked the lion…') carries only 1 mark but asks for an explanation. The answer space (3 lines) and the memo answer (4 sentences) suggest a longer response is expected. 1 mark for a multi-sentence explanation feels under-marked, or the question should be worth 2 marks.

---

### What we want from your review

1. Open the DOCX file. Read it as if you received it from a colleague.
2. Would you publish it for your class as-is? With minor edits? Not at all?
3. Look at the AI moderator's verdict above. Does it match your judgement?
   - If the AI said PASS but you would NOT publish: what did it miss?
   - If the AI flagged BLOCKING issues but you would publish anyway: which flags are pedantic?
4. Are there ANY pedagogical issues the AI didn't catch?
