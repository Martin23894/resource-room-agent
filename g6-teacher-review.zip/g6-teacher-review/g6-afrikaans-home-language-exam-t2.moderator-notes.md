# g6-afrikaans-home-language-exam-t2

**AI moderator verdict:** NEEDS_WORK  |  **score:** 3/5  |  **version:** original

## AI recommendation

This is a well-structured, culturally relevant exam with sound memo answers and good question design overall. The passage is appropriate and the visual stimulus is detailed. However, there are four ADVISORY issues that should be addressed before publication: (1) Q4.3's cognitive-level labelling is incorrect (labelled Inferential but tests Reorganisation); (2) Q2.1 asks for four examples when only three are explicitly stated, creating ambiguity; (3) the subject line indicates Afrikaans Home Language but the entire exam is in English, which requires clarification per CAPS; and (4) Q4.1 memo uses ambiguous slash notation in the indirect speech answer. None of these are blocking errors, but they should be corrected in a targeted regen pass to ensure consistency with CAPS guidelines and remove confusion for teachers marking the paper. With these fixes applied, the paper is publishable.

## Dimension scores (1-5)

| Dimension | Score | Notes |
|---|---|---|
| memoAccuracy | 4/5 | Memo answers are factually sound and aligned with the passage. Marking guidance is actionable, though some open-ended questions (1.7, 4.3) could benefit from more specific exemplars. |
| cognitiveLevelIntegrity | 3/5 | Most questions align with labelled levels, but 4.3 is labelled 'Inferential' when completing a conditional sentence is fundamentally 'Reorganisation' (applying a grammatical rule). Q1.4 border-line as it requires restatement rather than inference. |
| topicAlignment | 4/5 | Questions mostly align with their topics. The 'Junie-kontroletoets' topic label is repeated across all Section A/B questions without differentiation, which creates minor clarity issues. |
| markFairness | 4/5 | Mark allocations are generally proportional. Literal/recall questions = 1–2 marks; Reorganisation = 1–3 marks; Inferential = 2–4 marks; Evaluation = 3–4 marks. Coherent scaling. |
| mcqQuality | 5/5 | Q4.7 is well-constructed: single correct option (evaporates, b), grammatically parallel distractors (evaporate/evaporated), and plausible for Grade 6. |
| questionClarity | 4/5 | Most stems are clear and grade-appropriate. Q2.1 asks for 'FOUR ways' but the passage contains only three explicit water-wasting examples (taps, showers, gardens), requiring learners to infer 'dripping taps' as a fourth—this ambiguity creates a minor clarity issue. |
| stimulusQuality | 5/5 | Passage is coherent, age-appropriate (280 words), and internally consistent. Visual stimulus description is detailed and sufficient. All stimulusRefs resolve correctly. |
| capsCompliance | 4/5 | Cover page is complete with learner fields and instructions. Sections progress from Literal (A/1) through Reorganisation (B/2) to Inferential and Evaluation (C/3, D/4), broadly adhering to Barrett's progression. However, Section D mixes Literal, Reorganisation, and Inferential without explicit re-ordering. |
| languageRegister | 4/5 | English language is grammatically correct and register is appropriate for Grade 6. Afrikaans topics are referenced but the exam itself is in English; topic labels use Afrikaans accurately. |
| biasSensitivity | 4/5 | No stereotyping detected. Stimuli are inclusive and water scarcity is presented as a genuine SA issue affecting all communities. Language is neutral and respectful. |
| culturalContext | 5/5 | Water scarcity is a significant SA context; passage explicitly references South Africa's water challenges. Department of Water and Sanitation is an authentic SA government institution. Highly culturally relevant. |
| curriculumCoverage | 4/5 | Paper covers reading (literal, reorganisation, inferential, evaluation), summary, visual-text analysis, and language structures (indirect speech, passive voice, conditionals, figures of speech, punctuation, vocabulary, agreement). Reasonable breadth for a Term 2 exam, though limited to one stimulus passage. |

## Advisory issues (4)

- **Q4.3 — cognitiveLevelIntegrity**: Q4.3 is labelled 'Inferential' but asks learners to complete a conditional sentence: 'If people stopped wasting water, __________.' This is fundamentally a grammar exercise requiring application of a standard form (conditional clause with 'would + base verb'), not inference beyond the text. The cognitive demand is Reorganisation (rule-application), not Inferential.
- **Q2.1 — questionClarity**: Q2.1 asks: 'List FOUR ways in which people in cities waste water, as mentioned in the passage.' The passage explicitly states only three examples: leaving taps running while brushing teeth, taking long showers, and watering gardens during the hottest part of the day. A fourth item (dripping taps causing waste) is mentioned later but as a separate quantified waste problem, not explicitly as a city-dwelling practice. Learners must infer or conflate ideas to list four, creating ambiguity about whether they have read carefully or made unsupported inferences.
- **Qcover — capsCompliance**: The exam is stated to be in subject 'Afrikaans Home Language' (meta.subject) with a topicScope that lists Afrikaans learning outcomes. However, the entire exam (instructions, stimuli, questions, memo) is in English, not Afrikaans. This is a mismatch: either the exam should be in Afrikaans (as stated in the subject line), or the subject line should read 'Afrikaans Home Language (English Assessment)' or similar. CAPS requires clarity on language of instruction.
- **Q4.1 — memoAccuracy**: Q4.1 memo answer: 'The teacher said that water was their most precious resource and that they had to / must protect it.' The slash notation (had to / must) is ambiguous for marking. In indirect speech from direct speech 'must', the standard conversion is 'had to' (past obligation), not 'must' (present). The memo should clarify that 'had to' is the required form, or accept 'must' as a variant with guidance.

---

### What we want from your review

1. Open the DOCX file. Read it as if you received it from a colleague.
2. Would you publish it for your class as-is? With minor edits? Not at all?
3. Look at the AI moderator's verdict above. Does it match your judgement?
   - If the AI said PASS but you would NOT publish: what did it miss?
   - If the AI flagged BLOCKING issues but you would publish anyway: which flags are pedantic?
4. Are there ANY pedagogical issues the AI didn't catch?
