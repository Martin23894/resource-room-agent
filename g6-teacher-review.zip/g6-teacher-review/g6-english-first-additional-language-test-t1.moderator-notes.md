# g6-english-first-additional-language-test-t1

**AI moderator verdict:** NEEDS_WORK  |  **score:** 3/5  |  **version:** original

## AI recommendation

This Grade 6 English FAL test is well-constructed in terms of stimulus quality, language register, and cultural relevance, but it has critical flaws in cognitive level labeling and mark allocation that must be addressed before publication. The most pressing issue is Question 1.4, which asks for two pieces of information but is marked out of 1 mark and is mislabeled cognitively. Question 7.1 (a full summary paragraph) is drastically undermarked at 1 mark compared to other 3-mark writing tasks. Additionally, five questions across Section B are mislabeled with cognitive levels that do not match their actual demand (4.3, 6.1, 5.2, 6.2 are mechanical/routine but labelled Inferential or Inferential-adjacent). These mismatches will confuse teachers using the cognitive framework to track learner progress. The paper can be fixed with targeted corrections to mark allocations and cognitive level labels; no stimulus or question content regeneration is needed. Recommend NEEDS_WORK with high priority on cognitive level review.

## Dimension scores (1-5)

| Dimension | Score | Notes |
|---|---|---|
| memoAccuracy | 4/5 | Most memo answers are accurate and align with stimulus text. Minor concern: Question 1.4 asks for TWO ways to use the money but is marked out of only 1 mark—the memo guidance states '[Marks awarded: 1 mark] For each correct use' which is unclear (two uses but one mark total?). This creates grading ambiguity rather than factual error. |
| cognitiveLevelIntegrity | 2/5 | Multiple mismatches between labelled cognitive level and actual question demand. Question 1.4 is labelled 'Reorganisation' but asks for direct information extraction from the text (should be 'Literal'). Question 4.3 is labelled 'Inferential' but is a mechanical tense change task (should be 'Reorganisation'). Question 6.1 is labelled 'Inferential' (word division is not inferential—it's a mechanical skill). Question 6.2 is labelled 'Inferential' but asks learners to create a sentence using a dictionary definition (closer to 'Reorganisation'). Question 5.2 is labelled 'Inferential' but punctuation insertion is a routine skill. |
| topicAlignment | 4/5 | Each question's stem aligns well with its stated topic. Topics are drawn from the prescribed curriculum scope and tested appropriately throughout. |
| markFairness | 3/5 | Significant fairness issue: Question 1.4 asks for TWO ways to use the prize money but is allocated only 1 mark total—disproportionate to the demand for two pieces of information. Question 1.5 (7 marks) for a short explanation is generously marked compared to 2-mark short answers. Questions 7.1 (1 mark for a full summary paragraph) and 7.2 (3 marks for a narrative paragraph) create confusion: are they valued equally per word, or is the summary undermarked? |
| mcqQuality | 5/5 | Only one MCQ (3.3.1) in the paper; it is well-formed with a single correct answer (Those), a plausible distractor (This), and correct grammar. No issues detected. |
| questionClarity | 4/5 | Most questions are clearly worded and unambiguous. Minor note: Question 1.6 uses 'Do you think your school should also have a garden?' which could be interpreted as asking learners about their actual school's circumstances rather than inviting a personal opinion. Question 4.2 and 4.3 clearly signal tense change tasks with 'Rewrite... in the PAST/FUTURE TENSE', which is good. |
| stimulusQuality | 5/5 | Both stimuli are well-presented. The newspaper article is coherent, age-appropriate, and clearly uses SA names and context (Limpopo, Thabo Dlamini, Mrs Nomsa Khumalo, rands). The bar chart description is detailed enough to answer the questions. Word count (198 words) is appropriate for Grade 6. |
| capsCompliance | 4/5 | Cover page is complete with all required fields (name, surname, date, examiner, time, total, subject, grade, term, instructions, duration). Sections progress from Reading and Viewing (A) → Language (B) → Writing (C), which loosely follows a low-to-high cognitive structure, though Section B questions vary significantly in cognitive demand. |
| languageRegister | 5/5 | Grammar and spelling are consistently correct throughout the question paper, memo, and rubric. Register is appropriate for Grade 6 English FAL—accessible but not overly simplistic. No language errors detected. |
| biasSensitivity | 5/5 | Paper demonstrates good cultural diversity: SA-specific names (Thabo Dlamini, Nomsa Khumalo), SA setting (Limpopo, Pretoria), and gender-neutral language (the garden committee and learners are described without stereotyping). No socioeconomic, racial, or gender bias detected. |
| culturalContext | 5/5 | Stimulus is firmly grounded in SA context: Limpopo province, rands (R50 000), South African school structure, and diverse South African names. All references are culturally appropriate and relevant to learners' lived experience. |
| curriculumCoverage | 4/5 | The paper covers most of the prescribed topics: Reading (newspaper article, information text); Writing (summary, narrative, SMS); Language (nouns, pronouns, subject-verb agreement, tenses, punctuation, word division, dictionary use). However, there is no extended novelette reading, and the visual text (bar chart) is relatively simple. Coverage is reasonable but not comprehensive. |

## BLOCKING issues (4)

- **Q1.4 — markFairness**
  - Issue: Question asks 'Give TWO ways' the school will use the R50 000 prize money but is allocated only 1 mark total. The memo states '[Marks awarded: 1 mark] For each correct use of the prize money' which is contradictory—if one mark per use, two uses should be worth 2 marks. This creates ambiguity in how teachers should award marks.
  - Suggested fix: Either: (a) Revise the question to ask for ONE way (1 mark), or (b) Increase the allocation to 2 marks and clarify the memo to '[Marks awarded: 2 marks] 1 mark for each correct use of the prize money (max 2)'. Option (b) is recommended as the two-part demand is appropriate for the learners.

- **Q1.4 — cognitiveLevelIntegrity**
  - Issue: Question is labelled 'Reorganisation' but the demand is direct information extraction from the text: 'The school's principal, Mrs Nomsa Khumalo, said the money would be used to build a greenhouse and buy new gardening tools.' This is a Literal-level task (locate and identify stated facts), not Reorganisation (which requires reordering or summarising multiple pieces of information).
  - Suggested fix: Change the cognitive level label from 'Reorganisation' to 'Literal'.

- **Q4.3 — cognitiveLevelIntegrity**
  - Issue: Question is labelled 'Inferential' but the task is a mechanical tense conversion: 'Rewrite the following sentence in the FUTURE TENSE: "Thabo plants new seeds in the greenhouse."' This is a routine procedural task (apply the future tense rule), which aligns with Reorganisation, not Inferential (which requires deriving meaning not explicitly stated).
  - Suggested fix: Change the cognitive level label from 'Inferential' to 'Reorganisation'.

- **Q7.1 — markFairness**
  - Issue: Question asks for a full summary paragraph (5–7 sentences) incorporating FIVE specific points, marked out of only 1 mark. This is severely undermarked compared to Question 7.2 (narrative paragraph, 3 marks) and Question 8 (SMS, 3 marks). A summary task at this length and complexity warrants at least 3–5 marks.
  - Suggested fix: Increase marks for Question 7.1 from 1 to 4 marks. Revise the memo marking guidance to allocate partial credit: '1 mark for each of the 5 required points, minus 1 mark if responses are directly copied rather than paraphrased' (total 4, max 4). Alternatively, restructure the question to ask for a shorter summary (2–3 sentences) if 1 mark must be retained.

## Advisory issues (4)

- **Q6.1 — cognitiveLevelIntegrity**: Question is labelled 'Inferential': 'Divide the following word into syllables by writing a hyphen between each syllable: "responsibility"' This is a mechanical syllable-division skill, not inferential reasoning. Cognitive level should be 'Reorganisation' (routine application of phonetic rules).
- **Q5.2 — cognitiveLevelIntegrity**: Question is labelled 'Inferential': 'Add a COLON in the correct place in the following sentence...' Punctuation insertion is a routine language skill aligned with Reorganisation, not inferential reasoning which requires deriving unstated meaning.
- **Q6.2 — cognitiveLevelIntegrity**: Question is labelled 'Inferential': 'Using this definition, write your OWN sentence using the word "dedication".'' The task is to compose a sentence using a provided dictionary definition. This is closer to Reorganisation (applying given information) than Inferential. While it requires understanding the definition, it does not require deriving unstated meaning from a text.
- **Q1.5 — markFairness**: Question 1.5 is allocated 7 marks for an Inferential explanation task, while Question 1.4 (a Literal extraction task) is 1 mark and Question 1.3 (a list of two items) is 2 marks. The 7-mark allocation for a single short-answer explanation seems generous and creates an imbalance—Question 1.5 is worth more than Questions 1.1 + 1.2 + 1.3 combined (1+1+2 = 4 marks). Clarify whether this weighting is intentional.

---

### What we want from your review

1. Open the DOCX file. Read it as if you received it from a colleague.
2. Would you publish it for your class as-is? With minor edits? Not at all?
3. Look at the AI moderator's verdict above. Does it match your judgement?
   - If the AI said PASS but you would NOT publish: what did it miss?
   - If the AI flagged BLOCKING issues but you would publish anyway: which flags are pedantic?
4. Are there ANY pedagogical issues the AI didn't catch?
